﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace WindowsFormsApplication1
{
    
    public class Form3Src : Form
    { 
        public int testmember = 3;
 
        public Form3Src()
        {

        }

        public int test()
        {
            return 55;
        }

    }
}
