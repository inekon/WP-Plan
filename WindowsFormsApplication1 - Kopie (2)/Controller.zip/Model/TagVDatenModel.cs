﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class TagVDatenModel
    {
        public int ID;
        public int ID_TagV;
        public double Verteilung;

        public TagVDatenModel()
        {
            ID = 0;
            ID_TagV = 0;
            Verteilung = 0.0;
        }
    }
}
