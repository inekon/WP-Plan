namespace WindowsFormsApplication1
{
    partial class Form_Gebaeude1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gel�scht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode f�r die Designerunterst�tzung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Hilfe = new System.Windows.Forms.Button();
            this.btn_NeuerDatensatz = new System.Windows.Forms.Button();
            this.btn_Ueberschreiben = new System.Windows.Forms.Button();
            this.btn_Abbrechen = new System.Windows.Forms.Button();
            this.btn_Dialog2 = new System.Windows.Forms.Button();
            this.Label24 = new System.Windows.Forms.Label();
            this.Label27 = new System.Windows.Forms.Label();
            this.comboBox_Gebaeudeart = new System.Windows.Forms.ComboBox();
            this.comboBox_Baujahr = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox_Name = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox_Verwendung = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.comboBox_Gebaeudetyp = new System.Windows.Forms.ComboBox();
            this.textBox_Beschreibung = new System.Windows.Forms.TextBox();
            this.textBox_WohnflaecheGesamt = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.textBox_FlaecheNutzer = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.textBox_Fensterdurchlassgrad = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.comboBox_Bauart = new System.Windows.Forms.ComboBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.textBox_Raumhoehe = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.textBox_Waermegewinne = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.textBox_FFNord = new System.Windows.Forms.TextBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.textBox_FFSued = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.textBox_Gebaeude_Dachflaeche = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.textBox_FFOstWest = new System.Windows.Forms.TextBox();
            this.Label20 = new System.Windows.Forms.Label();
            this.textBox_Gebaeude_Grundflaeche = new System.Windows.Forms.TextBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.textBox_Sonstige_Flaechen = new System.Windows.Forms.TextBox();
            this.Label22 = new System.Windows.Forms.Label();
            this.textBox_Flaeche_Aussenwand = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox_UWert_Aussenwand = new System.Windows.Forms.TextBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.textBox_UWert_Dachflaeche = new System.Windows.Forms.TextBox();
            this.Label26 = new System.Windows.Forms.Label();
            this.textBox_UWert_Fenster = new System.Windows.Forms.TextBox();
            this.textBox_UWert_Grundflaeche = new System.Windows.Forms.TextBox();
            this.Label28 = new System.Windows.Forms.Label();
            this.textBox_UWert_Sonstige = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Hilfe
            // 
            this.btn_Hilfe.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Hilfe.Location = new System.Drawing.Point(36, 606);
            this.btn_Hilfe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Hilfe.Name = "btn_Hilfe";
            this.btn_Hilfe.Size = new System.Drawing.Size(77, 31);
            this.btn_Hilfe.TabIndex = 0;
            this.btn_Hilfe.Text = "Hilfe";
            this.btn_Hilfe.UseVisualStyleBackColor = true;
            // 
            // btn_NeuerDatensatz
            // 
            this.btn_NeuerDatensatz.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_NeuerDatensatz.Location = new System.Drawing.Point(319, 606);
            this.btn_NeuerDatensatz.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_NeuerDatensatz.Name = "btn_NeuerDatensatz";
            this.btn_NeuerDatensatz.Size = new System.Drawing.Size(99, 31);
            this.btn_NeuerDatensatz.TabIndex = 3;
            this.btn_NeuerDatensatz.Text = "Speichern unter";
            this.btn_NeuerDatensatz.UseVisualStyleBackColor = true;
            this.btn_NeuerDatensatz.Click += new System.EventHandler(this.btn_NeuerDatensatz_Click);
            // 
            // btn_Ueberschreiben
            // 
            this.btn_Ueberschreiben.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Ueberschreiben.Location = new System.Drawing.Point(458, 606);
            this.btn_Ueberschreiben.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Ueberschreiben.Name = "btn_Ueberschreiben";
            this.btn_Ueberschreiben.Size = new System.Drawing.Size(99, 31);
            this.btn_Ueberschreiben.TabIndex = 4;
            this.btn_Ueberschreiben.Text = "�berschreiben";
            this.btn_Ueberschreiben.UseVisualStyleBackColor = true;
            this.btn_Ueberschreiben.Click += new System.EventHandler(this.btn_Ueberschreiben_Click);
            // 
            // btn_Abbrechen
            // 
            this.btn_Abbrechen.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Abbrechen.Location = new System.Drawing.Point(599, 606);
            this.btn_Abbrechen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Abbrechen.Name = "btn_Abbrechen";
            this.btn_Abbrechen.Size = new System.Drawing.Size(87, 31);
            this.btn_Abbrechen.TabIndex = 5;
            this.btn_Abbrechen.Text = "Beenden";
            this.btn_Abbrechen.UseVisualStyleBackColor = true;
            this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
            // 
            // btn_Dialog2
            // 
            this.btn_Dialog2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Dialog2.Location = new System.Drawing.Point(536, 535);
            this.btn_Dialog2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Dialog2.Name = "btn_Dialog2";
            this.btn_Dialog2.Size = new System.Drawing.Size(150, 31);
            this.btn_Dialog2.TabIndex = 6;
            this.btn_Dialog2.Text = "Weitere Eingaben...";
            this.btn_Dialog2.UseVisualStyleBackColor = true;
            this.btn_Dialog2.Click += new System.EventHandler(this.btn_Dialog2_Click);
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label24.Location = new System.Drawing.Point(63, 423);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(77, 15);
            this.Label24.TabIndex = 43;
            this.Label24.Text = "Au�enwand :";
            this.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label27.Location = new System.Drawing.Point(210, 423);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(51, 15);
            this.Label27.TabIndex = 48;
            this.Label27.Text = "Fenster :";
            this.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox_Gebaeudeart
            // 
            this.comboBox_Gebaeudeart.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBox_Gebaeudeart.Location = new System.Drawing.Point(384, 51);
            this.comboBox_Gebaeudeart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox_Gebaeudeart.Name = "comboBox_Gebaeudeart";
            this.comboBox_Gebaeudeart.Size = new System.Drawing.Size(163, 23);
            this.comboBox_Gebaeudeart.TabIndex = 54;
            // 
            // comboBox_Baujahr
            // 
            this.comboBox_Baujahr.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBox_Baujahr.Location = new System.Drawing.Point(102, 84);
            this.comboBox_Baujahr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox_Baujahr.Name = "comboBox_Baujahr";
            this.comboBox_Baujahr.Size = new System.Drawing.Size(140, 23);
            this.comboBox_Baujahr.TabIndex = 55;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox_Name);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.comboBox_Verwendung);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Label1);
            this.groupBox1.Controls.Add(this.Label2);
            this.groupBox1.Controls.Add(this.comboBox_Gebaeudetyp);
            this.groupBox1.Controls.Add(this.textBox_Beschreibung);
            this.groupBox1.Controls.Add(this.textBox_WohnflaecheGesamt);
            this.groupBox1.Controls.Add(this.Label4);
            this.groupBox1.Controls.Add(this.Label5);
            this.groupBox1.Controls.Add(this.comboBox_Baujahr);
            this.groupBox1.Controls.Add(this.comboBox_Gebaeudeart);
            this.groupBox1.Controls.Add(this.textBox_FlaecheNutzer);
            this.groupBox1.Controls.Add(this.Label6);
            this.groupBox1.Controls.Add(this.textBox_Fensterdurchlassgrad);
            this.groupBox1.Controls.Add(this.Label7);
            this.groupBox1.Controls.Add(this.comboBox_Bauart);
            this.groupBox1.Controls.Add(this.Label8);
            this.groupBox1.Controls.Add(this.Label9);
            this.groupBox1.Controls.Add(this.Label10);
            this.groupBox1.Controls.Add(this.Label12);
            this.groupBox1.Controls.Add(this.textBox_Raumhoehe);
            this.groupBox1.Controls.Add(this.Label13);
            this.groupBox1.Controls.Add(this.textBox_Waermegewinne);
            this.groupBox1.Controls.Add(this.Label14);
            this.groupBox1.Controls.Add(this.Label15);
            this.groupBox1.Location = new System.Drawing.Point(10, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(568, 316);
            this.groupBox1.TabIndex = 56;
            this.groupBox1.TabStop = false;
            // 
            // comboBox_Name
            // 
            this.comboBox_Name.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBox_Name.Location = new System.Drawing.Point(102, 20);
            this.comboBox_Name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox_Name.Name = "comboBox_Name";
            this.comboBox_Name.Size = new System.Drawing.Size(189, 23);
            this.comboBox_Name.TabIndex = 86;
            this.comboBox_Name.SelectedIndexChanged += new System.EventHandler(this.comboBox_Name_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label23.Location = new System.Drawing.Point(298, 87);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(80, 15);
            this.label23.TabIndex = 85;
            this.label23.Text = "Verwendung :";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox_Verwendung
            // 
            this.comboBox_Verwendung.ForeColor = System.Drawing.Color.Black;
            this.comboBox_Verwendung.FormattingEnabled = true;
            this.comboBox_Verwendung.Items.AddRange(new object[] {
            "Nicht Wohngebaeude",
            "Wohngebaeude"});
            this.comboBox_Verwendung.Location = new System.Drawing.Point(384, 83);
            this.comboBox_Verwendung.Name = "comboBox_Verwendung";
            this.comboBox_Verwendung.Size = new System.Drawing.Size(163, 25);
            this.comboBox_Verwendung.TabIndex = 84;
            this.comboBox_Verwendung.Text = "Wohngebaeude";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label32.Location = new System.Drawing.Point(43, 87);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 15);
            this.label32.TabIndex = 83;
            this.label32.Text = "Baujahr :";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label31.Location = new System.Drawing.Point(304, 54);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 15);
            this.label31.TabIndex = 82;
            this.label31.Text = "Geb�udeart :";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(541, 224);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 15);
            this.label11.TabIndex = 81;
            this.label11.Text = "m";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label3.Location = new System.Drawing.Point(14, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 15);
            this.label3.TabIndex = 80;
            this.label3.Text = "Beschreibung :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label1.ForeColor = System.Drawing.Color.Black;
            this.Label1.Location = new System.Drawing.Point(48, 20);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(45, 15);
            this.Label1.TabIndex = 58;
            this.Label1.Text = "Name :";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label2.Location = new System.Drawing.Point(18, 54);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(77, 15);
            this.Label2.TabIndex = 59;
            this.Label2.Text = "Geb�udetyp :";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox_Gebaeudetyp
            // 
            this.comboBox_Gebaeudetyp.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBox_Gebaeudetyp.Location = new System.Drawing.Point(101, 51);
            this.comboBox_Gebaeudetyp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox_Gebaeudetyp.Name = "comboBox_Gebaeudetyp";
            this.comboBox_Gebaeudetyp.Size = new System.Drawing.Size(189, 23);
            this.comboBox_Gebaeudetyp.TabIndex = 61;
            // 
            // textBox_Beschreibung
            // 
            this.textBox_Beschreibung.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Beschreibung.Location = new System.Drawing.Point(102, 116);
            this.textBox_Beschreibung.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Beschreibung.Multiline = true;
            this.textBox_Beschreibung.Name = "textBox_Beschreibung";
            this.textBox_Beschreibung.Size = new System.Drawing.Size(432, 63);
            this.textBox_Beschreibung.TabIndex = 62;
            // 
            // textBox_WohnflaecheGesamt
            // 
            this.textBox_WohnflaecheGesamt.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_WohnflaecheGesamt.Location = new System.Drawing.Point(180, 190);
            this.textBox_WohnflaecheGesamt.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_WohnflaecheGesamt.Name = "textBox_WohnflaecheGesamt";
            this.textBox_WohnflaecheGesamt.Size = new System.Drawing.Size(56, 23);
            this.textBox_WohnflaecheGesamt.TabIndex = 63;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label4.Location = new System.Drawing.Point(49, 192);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(112, 15);
            this.Label4.TabIndex = 64;
            this.Label4.Text = "Wohn-/Nutzfl�che :";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label5.Location = new System.Drawing.Point(49, 223);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(93, 15);
            this.Label5.TabIndex = 65;
            this.Label5.Text = "Fl�che / Nutzer :";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_FlaecheNutzer
            // 
            this.textBox_FlaecheNutzer.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_FlaecheNutzer.Location = new System.Drawing.Point(180, 221);
            this.textBox_FlaecheNutzer.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_FlaecheNutzer.Name = "textBox_FlaecheNutzer";
            this.textBox_FlaecheNutzer.Size = new System.Drawing.Size(56, 23);
            this.textBox_FlaecheNutzer.TabIndex = 66;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label6.Location = new System.Drawing.Point(49, 256);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(122, 15);
            this.Label6.TabIndex = 67;
            this.Label6.Text = "Fensterdurchla�grad :";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Fensterdurchlassgrad
            // 
            this.textBox_Fensterdurchlassgrad.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Fensterdurchlassgrad.Location = new System.Drawing.Point(179, 254);
            this.textBox_Fensterdurchlassgrad.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Fensterdurchlassgrad.Name = "textBox_Fensterdurchlassgrad";
            this.textBox_Fensterdurchlassgrad.Size = new System.Drawing.Size(56, 23);
            this.textBox_Fensterdurchlassgrad.TabIndex = 68;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label7.Location = new System.Drawing.Point(334, 190);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(47, 15);
            this.Label7.TabIndex = 69;
            this.Label7.Text = "Bauart :";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBox_Bauart
            // 
            this.comboBox_Bauart.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.comboBox_Bauart.Location = new System.Drawing.Point(394, 188);
            this.comboBox_Bauart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox_Bauart.Name = "comboBox_Bauart";
            this.comboBox_Bauart.Size = new System.Drawing.Size(140, 23);
            this.comboBox_Bauart.TabIndex = 70;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.BackColor = System.Drawing.Color.Black;
            this.Label8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(244, 192);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(22, 15);
            this.Label8.TabIndex = 71;
            this.Label8.Text = "m�";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.BackColor = System.Drawing.Color.Black;
            this.Label9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(244, 223);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(22, 15);
            this.Label9.TabIndex = 72;
            this.Label9.Text = "m�";
            this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.BackColor = System.Drawing.Color.Black;
            this.Label10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label10.ForeColor = System.Drawing.Color.White;
            this.Label10.Location = new System.Drawing.Point(244, 256);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(51, 15);
            this.Label10.TabIndex = 73;
            this.Label10.Text = "(z.B. 0,4)";
            this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label12.Location = new System.Drawing.Point(334, 224);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(71, 15);
            this.Label12.TabIndex = 74;
            this.Label12.Text = "Raumh�he :";
            this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Raumhoehe
            // 
            this.textBox_Raumhoehe.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Raumhoehe.Location = new System.Drawing.Point(478, 224);
            this.textBox_Raumhoehe.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Raumhoehe.Name = "textBox_Raumhoehe";
            this.textBox_Raumhoehe.Size = new System.Drawing.Size(56, 23);
            this.textBox_Raumhoehe.TabIndex = 75;
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label13.Location = new System.Drawing.Point(334, 256);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(136, 15);
            this.Label13.TabIndex = 76;
            this.Label13.Text = "Interne W�rmegewinne :";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Waermegewinne
            // 
            this.textBox_Waermegewinne.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Waermegewinne.Location = new System.Drawing.Point(478, 254);
            this.textBox_Waermegewinne.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Waermegewinne.Name = "textBox_Waermegewinne";
            this.textBox_Waermegewinne.Size = new System.Drawing.Size(56, 23);
            this.textBox_Waermegewinne.TabIndex = 77;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label14.Location = new System.Drawing.Point(506, 186);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(18, 15);
            this.Label14.TabIndex = 78;
            this.Label14.Text = "m";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.BackColor = System.Drawing.Color.Black;
            this.Label15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label15.ForeColor = System.Drawing.Color.White;
            this.Label15.Location = new System.Drawing.Point(541, 254);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(18, 15);
            this.Label15.TabIndex = 79;
            this.Label15.Text = "W";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Label16);
            this.groupBox2.Controls.Add(this.textBox_FFNord);
            this.groupBox2.Controls.Add(this.Label17);
            this.groupBox2.Controls.Add(this.textBox_FFSued);
            this.groupBox2.Controls.Add(this.Label18);
            this.groupBox2.Controls.Add(this.textBox_Gebaeude_Dachflaeche);
            this.groupBox2.Controls.Add(this.Label19);
            this.groupBox2.Controls.Add(this.textBox_FFOstWest);
            this.groupBox2.Controls.Add(this.Label20);
            this.groupBox2.Controls.Add(this.textBox_Gebaeude_Grundflaeche);
            this.groupBox2.Controls.Add(this.Label21);
            this.groupBox2.Controls.Add(this.textBox_Sonstige_Flaechen);
            this.groupBox2.Controls.Add(this.Label22);
            this.groupBox2.Controls.Add(this.textBox_Flaeche_Aussenwand);
            this.groupBox2.Location = new System.Drawing.Point(10, 324);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(568, 164);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Fl�chen [m�]";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label16.Location = new System.Drawing.Point(50, 29);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(113, 15);
            this.Label16.TabIndex = 43;
            this.Label16.Text = "Fensterfl�che Nord :";
            this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_FFNord
            // 
            this.textBox_FFNord.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_FFNord.Location = new System.Drawing.Point(176, 29);
            this.textBox_FFNord.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_FFNord.Name = "textBox_FFNord";
            this.textBox_FFNord.Size = new System.Drawing.Size(77, 23);
            this.textBox_FFNord.TabIndex = 44;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label17.Location = new System.Drawing.Point(50, 61);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(106, 15);
            this.Label17.TabIndex = 45;
            this.Label17.Text = "Fensterfl�che S�d :";
            this.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_FFSued
            // 
            this.textBox_FFSued.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_FFSued.Location = new System.Drawing.Point(176, 61);
            this.textBox_FFSued.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_FFSued.Name = "textBox_FFSued";
            this.textBox_FFSued.Size = new System.Drawing.Size(77, 23);
            this.textBox_FFSued.TabIndex = 46;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label18.Location = new System.Drawing.Point(50, 91);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(122, 15);
            this.Label18.TabIndex = 47;
            this.Label18.Text = "Geb�ude Dachfl�che :";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Gebaeude_Dachflaeche
            // 
            this.textBox_Gebaeude_Dachflaeche.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Gebaeude_Dachflaeche.Location = new System.Drawing.Point(176, 91);
            this.textBox_Gebaeude_Dachflaeche.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Gebaeude_Dachflaeche.Name = "textBox_Gebaeude_Dachflaeche";
            this.textBox_Gebaeude_Dachflaeche.Size = new System.Drawing.Size(77, 23);
            this.textBox_Gebaeude_Dachflaeche.TabIndex = 48;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label19.Location = new System.Drawing.Point(296, 29);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(144, 15);
            this.Label19.TabIndex = 49;
            this.Label19.Text = "Fensterfl�che Ost + West :";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_FFOstWest
            // 
            this.textBox_FFOstWest.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_FFOstWest.Location = new System.Drawing.Point(448, 29);
            this.textBox_FFOstWest.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_FFOstWest.Name = "textBox_FFOstWest";
            this.textBox_FFOstWest.Size = new System.Drawing.Size(77, 23);
            this.textBox_FFOstWest.TabIndex = 50;
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label20.Location = new System.Drawing.Point(296, 76);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(128, 15);
            this.Label20.TabIndex = 51;
            this.Label20.Text = "Geb�ude Grundfl�che :";
            this.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Gebaeude_Grundflaeche
            // 
            this.textBox_Gebaeude_Grundflaeche.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Gebaeude_Grundflaeche.Location = new System.Drawing.Point(448, 76);
            this.textBox_Gebaeude_Grundflaeche.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Gebaeude_Grundflaeche.Name = "textBox_Gebaeude_Grundflaeche";
            this.textBox_Gebaeude_Grundflaeche.Size = new System.Drawing.Size(77, 23);
            this.textBox_Gebaeude_Grundflaeche.TabIndex = 52;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label21.Location = new System.Drawing.Point(296, 109);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(101, 15);
            this.Label21.TabIndex = 53;
            this.Label21.Text = "sonstige Fl�chen :";
            this.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Sonstige_Flaechen
            // 
            this.textBox_Sonstige_Flaechen.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Sonstige_Flaechen.Location = new System.Drawing.Point(448, 109);
            this.textBox_Sonstige_Flaechen.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Sonstige_Flaechen.Name = "textBox_Sonstige_Flaechen";
            this.textBox_Sonstige_Flaechen.Size = new System.Drawing.Size(77, 23);
            this.textBox_Sonstige_Flaechen.TabIndex = 54;
            // 
            // Label22
            // 
            this.Label22.AutoSize = true;
            this.Label22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label22.Location = new System.Drawing.Point(50, 126);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(114, 15);
            this.Label22.TabIndex = 55;
            this.Label22.Text = "Fl�che Au�enwand :";
            this.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Flaeche_Aussenwand
            // 
            this.textBox_Flaeche_Aussenwand.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Flaeche_Aussenwand.Location = new System.Drawing.Point(176, 124);
            this.textBox_Flaeche_Aussenwand.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Flaeche_Aussenwand.Name = "textBox_Flaeche_Aussenwand";
            this.textBox_Flaeche_Aussenwand.Size = new System.Drawing.Size(77, 23);
            this.textBox_Flaeche_Aussenwand.TabIndex = 56;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.textBox_UWert_Aussenwand);
            this.groupBox3.Controls.Add(this.Label25);
            this.groupBox3.Controls.Add(this.textBox_UWert_Dachflaeche);
            this.groupBox3.Controls.Add(this.Label26);
            this.groupBox3.Controls.Add(this.textBox_UWert_Fenster);
            this.groupBox3.Controls.Add(this.textBox_UWert_Grundflaeche);
            this.groupBox3.Controls.Add(this.Label28);
            this.groupBox3.Controls.Add(this.textBox_UWert_Sonstige);
            this.groupBox3.Location = new System.Drawing.Point(10, 494);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(509, 97);
            this.groupBox3.TabIndex = 58;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "U-Werte [W/m�K]";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label30.Location = new System.Drawing.Point(191, 31);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(51, 15);
            this.label30.TabIndex = 62;
            this.label30.Text = "Fenster :";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label29.Location = new System.Drawing.Point(21, 28);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 15);
            this.label29.TabIndex = 61;
            this.label29.Text = "Au�enwand :";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_UWert_Aussenwand
            // 
            this.textBox_UWert_Aussenwand.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_UWert_Aussenwand.Location = new System.Drawing.Point(101, 28);
            this.textBox_UWert_Aussenwand.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_UWert_Aussenwand.Name = "textBox_UWert_Aussenwand";
            this.textBox_UWert_Aussenwand.Size = new System.Drawing.Size(56, 23);
            this.textBox_UWert_Aussenwand.TabIndex = 53;
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label25.Location = new System.Drawing.Point(18, 58);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(72, 15);
            this.Label25.TabIndex = 54;
            this.Label25.Text = "Dachfl�che :";
            this.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_UWert_Dachflaeche
            // 
            this.textBox_UWert_Dachflaeche.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_UWert_Dachflaeche.Location = new System.Drawing.Point(101, 58);
            this.textBox_UWert_Dachflaeche.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_UWert_Dachflaeche.Name = "textBox_UWert_Dachflaeche";
            this.textBox_UWert_Dachflaeche.Size = new System.Drawing.Size(56, 23);
            this.textBox_UWert_Dachflaeche.TabIndex = 55;
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label26.Location = new System.Drawing.Point(190, 58);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(78, 15);
            this.Label26.TabIndex = 56;
            this.Label26.Text = "Grundfl�che :";
            this.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_UWert_Fenster
            // 
            this.textBox_UWert_Fenster.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_UWert_Fenster.Location = new System.Drawing.Point(272, 28);
            this.textBox_UWert_Fenster.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_UWert_Fenster.Name = "textBox_UWert_Fenster";
            this.textBox_UWert_Fenster.Size = new System.Drawing.Size(56, 23);
            this.textBox_UWert_Fenster.TabIndex = 57;
            // 
            // textBox_UWert_Grundflaeche
            // 
            this.textBox_UWert_Grundflaeche.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_UWert_Grundflaeche.Location = new System.Drawing.Point(272, 58);
            this.textBox_UWert_Grundflaeche.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_UWert_Grundflaeche.Name = "textBox_UWert_Grundflaeche";
            this.textBox_UWert_Grundflaeche.Size = new System.Drawing.Size(56, 23);
            this.textBox_UWert_Grundflaeche.TabIndex = 58;
            // 
            // Label28
            // 
            this.Label28.AutoSize = true;
            this.Label28.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label28.Location = new System.Drawing.Point(363, 57);
            this.Label28.Name = "Label28";
            this.Label28.Size = new System.Drawing.Size(63, 15);
            this.Label28.TabIndex = 59;
            this.Label28.Text = "Sonstiges :";
            this.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_UWert_Sonstige
            // 
            this.textBox_UWert_Sonstige.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_UWert_Sonstige.Location = new System.Drawing.Point(429, 55);
            this.textBox_UWert_Sonstige.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_UWert_Sonstige.Name = "textBox_UWert_Sonstige";
            this.textBox_UWert_Sonstige.Size = new System.Drawing.Size(56, 23);
            this.textBox_UWert_Sonstige.TabIndex = 60;
            // 
            // Form_Gebaeude1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 651);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_Hilfe);
            this.Controls.Add(this.btn_NeuerDatensatz);
            this.Controls.Add(this.btn_Ueberschreiben);
            this.Controls.Add(this.btn_Abbrechen);
            this.Controls.Add(this.btn_Dialog2);
            this.Controls.Add(this.Label24);
            this.Controls.Add(this.Label27);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form_Gebaeude1";
            this.Text = "Geb�udedaten: Fl�schen, U-Werte";
            this.Load += new System.EventHandler(this.Form_Gebaeude1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Hilfe;
private System.Windows.Forms.Button btn_NeuerDatensatz;
private System.Windows.Forms.Button btn_Ueberschreiben;
private System.Windows.Forms.Button btn_Abbrechen;
private System.Windows.Forms.Button btn_Dialog2;
private System.Windows.Forms.Label Label24;
private System.Windows.Forms.Label Label27;
private System.Windows.Forms.ComboBox comboBox_Gebaeudeart;
private System.Windows.Forms.ComboBox comboBox_Baujahr;
private System.Windows.Forms.GroupBox groupBox1;
private System.Windows.Forms.Label label11;
private System.Windows.Forms.Label label3;
private System.Windows.Forms.Label Label1;
private System.Windows.Forms.Label Label2;
private System.Windows.Forms.ComboBox comboBox_Gebaeudetyp;
private System.Windows.Forms.TextBox textBox_Beschreibung;
private System.Windows.Forms.TextBox textBox_WohnflaecheGesamt;
private System.Windows.Forms.Label Label4;
private System.Windows.Forms.Label Label5;
private System.Windows.Forms.TextBox textBox_FlaecheNutzer;
private System.Windows.Forms.Label Label6;
private System.Windows.Forms.TextBox textBox_Fensterdurchlassgrad;
private System.Windows.Forms.Label Label7;
private System.Windows.Forms.ComboBox comboBox_Bauart;
private System.Windows.Forms.Label Label8;
private System.Windows.Forms.Label Label9;
private System.Windows.Forms.Label Label10;
private System.Windows.Forms.Label Label12;
private System.Windows.Forms.TextBox textBox_Raumhoehe;
private System.Windows.Forms.Label Label13;
private System.Windows.Forms.TextBox textBox_Waermegewinne;
private System.Windows.Forms.Label Label14;
private System.Windows.Forms.Label Label15;
private System.Windows.Forms.GroupBox groupBox2;
private System.Windows.Forms.Label Label16;
private System.Windows.Forms.TextBox textBox_FFNord;
private System.Windows.Forms.Label Label17;
private System.Windows.Forms.TextBox textBox_FFSued;
private System.Windows.Forms.Label Label18;
private System.Windows.Forms.TextBox textBox_Gebaeude_Dachflaeche;
private System.Windows.Forms.Label Label19;
private System.Windows.Forms.TextBox textBox_FFOstWest;
private System.Windows.Forms.Label Label20;
private System.Windows.Forms.TextBox textBox_Gebaeude_Grundflaeche;
private System.Windows.Forms.Label Label21;
private System.Windows.Forms.TextBox textBox_Sonstige_Flaechen;
private System.Windows.Forms.Label Label22;
private System.Windows.Forms.TextBox textBox_Flaeche_Aussenwand;
private System.Windows.Forms.GroupBox groupBox3;
private System.Windows.Forms.Label label30;
private System.Windows.Forms.Label label29;
private System.Windows.Forms.TextBox textBox_UWert_Aussenwand;
private System.Windows.Forms.Label Label25;
private System.Windows.Forms.TextBox textBox_UWert_Dachflaeche;
private System.Windows.Forms.Label Label26;
private System.Windows.Forms.TextBox textBox_UWert_Fenster;
private System.Windows.Forms.TextBox textBox_UWert_Grundflaeche;
private System.Windows.Forms.Label Label28;
private System.Windows.Forms.TextBox textBox_UWert_Sonstige;
private System.Windows.Forms.Label label32;
private System.Windows.Forms.Label label31;
private System.Windows.Forms.Label label23;
private System.Windows.Forms.ComboBox comboBox_Verwendung;
private System.Windows.Forms.ComboBox comboBox_Name;


 
    }
}