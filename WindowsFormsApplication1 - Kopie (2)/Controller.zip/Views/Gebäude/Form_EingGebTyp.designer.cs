namespace WindowsFormsApplication1
{
    partial class Form_EingGebTyp
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gel�scht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode f�r die Designerunterst�tzung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.textBox_Beschreibung = new System.Windows.Forms.TextBox();
            this.btn_EingneuerTyp = new System.Windows.Forms.Button();
            this.btn_Schliessen = new System.Windows.Forms.Button();
            this.listBox_Typename = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox_Kurve = new System.Windows.Forms.ListBox();
            this.Label27 = new System.Windows.Forms.Label();
            this.btn_Speichern = new System.Windows.Forms.Button();
            this.Label3 = new System.Windows.Forms.Label();
            this.st1 = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.st2 = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.st3 = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.st4 = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.st5 = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.st6 = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.st7 = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.st8 = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.st9 = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.st10 = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.st11 = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.st12 = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.st13 = new System.Windows.Forms.TextBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.st14 = new System.Windows.Forms.TextBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.st15 = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.st16 = new System.Windows.Forms.TextBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.st17 = new System.Windows.Forms.TextBox();
            this.Label20 = new System.Windows.Forms.Label();
            this.st18 = new System.Windows.Forms.TextBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.st19 = new System.Windows.Forms.TextBox();
            this.Label22 = new System.Windows.Forms.Label();
            this.st20 = new System.Windows.Forms.TextBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.st21 = new System.Windows.Forms.TextBox();
            this.Label24 = new System.Windows.Forms.Label();
            this.st22 = new System.Windows.Forms.TextBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.st23 = new System.Windows.Forms.TextBox();
            this.Label26 = new System.Windows.Forms.Label();
            this.st24 = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btn_Loeschen = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label1.Location = new System.Drawing.Point(28, 9);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(38, 13);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Name:";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label2.Location = new System.Drawing.Point(312, 15);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(75, 13);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Beschreibung:";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Beschreibung
            // 
            this.textBox_Beschreibung.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.textBox_Beschreibung.Location = new System.Drawing.Point(315, 33);
            this.textBox_Beschreibung.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Beschreibung.Multiline = true;
            this.textBox_Beschreibung.Name = "textBox_Beschreibung";
            this.textBox_Beschreibung.Size = new System.Drawing.Size(265, 57);
            this.textBox_Beschreibung.TabIndex = 3;
            // 
            // btn_EingneuerTyp
            // 
            this.btn_EingneuerTyp.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btn_EingneuerTyp.Location = new System.Drawing.Point(315, 114);
            this.btn_EingneuerTyp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_EingneuerTyp.Name = "btn_EingneuerTyp";
            this.btn_EingneuerTyp.Size = new System.Drawing.Size(96, 33);
            this.btn_EingneuerTyp.TabIndex = 5;
            this.btn_EingneuerTyp.Text = "Typ hinzuf�gen";
            this.btn_EingneuerTyp.UseVisualStyleBackColor = true;
            this.btn_EingneuerTyp.Click += new System.EventHandler(this.btn_EingneuerTyp_Click);
            // 
            // btn_Schliessen
            // 
            this.btn_Schliessen.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btn_Schliessen.Location = new System.Drawing.Point(582, 636);
            this.btn_Schliessen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Schliessen.Name = "btn_Schliessen";
            this.btn_Schliessen.Size = new System.Drawing.Size(77, 31);
            this.btn_Schliessen.TabIndex = 13;
            this.btn_Schliessen.Text = "OK";
            this.btn_Schliessen.UseVisualStyleBackColor = true;
            this.btn_Schliessen.Click += new System.EventHandler(this.btn_Schliessen_Click);
            // 
            // listBox_Typename
            // 
            this.listBox_Typename.ItemHeight = 17;
            this.listBox_Typename.Location = new System.Drawing.Point(31, 26);
            this.listBox_Typename.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox_Typename.Name = "listBox_Typename";
            this.listBox_Typename.Size = new System.Drawing.Size(223, 140);
            this.listBox_Typename.TabIndex = 14;
            this.listBox_Typename.SelectedIndexChanged += new System.EventHandler(this.listBox_Typename_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox_Kurve);
            this.groupBox1.Controls.Add(this.Label27);
            this.groupBox1.Controls.Add(this.Label3);
            this.groupBox1.Controls.Add(this.st1);
            this.groupBox1.Controls.Add(this.Label4);
            this.groupBox1.Controls.Add(this.st2);
            this.groupBox1.Controls.Add(this.Label5);
            this.groupBox1.Controls.Add(this.st3);
            this.groupBox1.Controls.Add(this.Label6);
            this.groupBox1.Controls.Add(this.st4);
            this.groupBox1.Controls.Add(this.Label7);
            this.groupBox1.Controls.Add(this.st5);
            this.groupBox1.Controls.Add(this.Label8);
            this.groupBox1.Controls.Add(this.st6);
            this.groupBox1.Controls.Add(this.Label9);
            this.groupBox1.Controls.Add(this.st7);
            this.groupBox1.Controls.Add(this.Label10);
            this.groupBox1.Controls.Add(this.st8);
            this.groupBox1.Controls.Add(this.Label11);
            this.groupBox1.Controls.Add(this.st9);
            this.groupBox1.Controls.Add(this.Label12);
            this.groupBox1.Controls.Add(this.st10);
            this.groupBox1.Controls.Add(this.Label13);
            this.groupBox1.Controls.Add(this.st11);
            this.groupBox1.Controls.Add(this.Label14);
            this.groupBox1.Controls.Add(this.st12);
            this.groupBox1.Controls.Add(this.Label15);
            this.groupBox1.Controls.Add(this.st13);
            this.groupBox1.Controls.Add(this.Label16);
            this.groupBox1.Controls.Add(this.st14);
            this.groupBox1.Controls.Add(this.Label17);
            this.groupBox1.Controls.Add(this.st15);
            this.groupBox1.Controls.Add(this.Label18);
            this.groupBox1.Controls.Add(this.st16);
            this.groupBox1.Controls.Add(this.Label19);
            this.groupBox1.Controls.Add(this.st17);
            this.groupBox1.Controls.Add(this.Label20);
            this.groupBox1.Controls.Add(this.st18);
            this.groupBox1.Controls.Add(this.Label21);
            this.groupBox1.Controls.Add(this.st19);
            this.groupBox1.Controls.Add(this.Label22);
            this.groupBox1.Controls.Add(this.st20);
            this.groupBox1.Controls.Add(this.Label23);
            this.groupBox1.Controls.Add(this.st21);
            this.groupBox1.Controls.Add(this.Label24);
            this.groupBox1.Controls.Add(this.st22);
            this.groupBox1.Controls.Add(this.Label25);
            this.groupBox1.Controls.Add(this.st23);
            this.groupBox1.Controls.Add(this.Label26);
            this.groupBox1.Controls.Add(this.st24);
            this.groupBox1.Location = new System.Drawing.Point(33, 177);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(622, 243);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stundenwerteeingabe [kW, kWh oder %]";
            // 
            // listBox_Kurve
            // 
            this.listBox_Kurve.ItemHeight = 17;
            this.listBox_Kurve.Location = new System.Drawing.Point(385, 53);
            this.listBox_Kurve.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox_Kurve.Name = "listBox_Kurve";
            this.listBox_Kurve.Size = new System.Drawing.Size(223, 157);
            this.listBox_Kurve.TabIndex = 111;
            this.listBox_Kurve.SelectedIndexChanged += new System.EventHandler(this.listBox_Kurve_SelectedIndexChanged);
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label27.Location = new System.Drawing.Point(382, 36);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(138, 13);
            this.Label27.TabIndex = 112;
            this.Label27.Text = "Kurvenverlauf f�r den Tag:";
            this.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_Speichern
            // 
            this.btn_Speichern.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btn_Speichern.Location = new System.Drawing.Point(436, 114);
            this.btn_Speichern.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Speichern.Name = "btn_Speichern";
            this.btn_Speichern.Size = new System.Drawing.Size(96, 33);
            this.btn_Speichern.TabIndex = 113;
            this.btn_Speichern.Text = "Typ Speichern";
            this.btn_Speichern.UseVisualStyleBackColor = true;
            this.btn_Speichern.Click += new System.EventHandler(this.btn_Speichern_Click);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label3.Location = new System.Drawing.Point(11, 36);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(13, 13);
            this.Label3.TabIndex = 63;
            this.Label3.Text = "1";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st1
            // 
            this.st1.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st1.Location = new System.Drawing.Point(32, 36);
            this.st1.Margin = new System.Windows.Forms.Padding(5);
            this.st1.Name = "st1";
            this.st1.Size = new System.Drawing.Size(70, 22);
            this.st1.TabIndex = 64;
            this.st1.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label4.Location = new System.Drawing.Point(11, 60);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(13, 13);
            this.Label4.TabIndex = 65;
            this.Label4.Text = "2";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st2
            // 
            this.st2.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st2.Location = new System.Drawing.Point(32, 60);
            this.st2.Margin = new System.Windows.Forms.Padding(5);
            this.st2.Name = "st2";
            this.st2.Size = new System.Drawing.Size(70, 22);
            this.st2.TabIndex = 66;
            this.st2.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label5.Location = new System.Drawing.Point(11, 83);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(13, 13);
            this.Label5.TabIndex = 67;
            this.Label5.Text = "3";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st3
            // 
            this.st3.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st3.Location = new System.Drawing.Point(32, 83);
            this.st3.Margin = new System.Windows.Forms.Padding(5);
            this.st3.Name = "st3";
            this.st3.Size = new System.Drawing.Size(70, 22);
            this.st3.TabIndex = 68;
            this.st3.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label6.Location = new System.Drawing.Point(11, 107);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(13, 13);
            this.Label6.TabIndex = 69;
            this.Label6.Text = "4";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st4
            // 
            this.st4.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st4.Location = new System.Drawing.Point(32, 107);
            this.st4.Margin = new System.Windows.Forms.Padding(5);
            this.st4.Name = "st4";
            this.st4.Size = new System.Drawing.Size(70, 22);
            this.st4.TabIndex = 70;
            this.st4.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label7.Location = new System.Drawing.Point(11, 130);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(13, 13);
            this.Label7.TabIndex = 71;
            this.Label7.Text = "5";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st5
            // 
            this.st5.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st5.Location = new System.Drawing.Point(32, 130);
            this.st5.Margin = new System.Windows.Forms.Padding(5);
            this.st5.Name = "st5";
            this.st5.Size = new System.Drawing.Size(70, 22);
            this.st5.TabIndex = 72;
            this.st5.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label8.Location = new System.Drawing.Point(11, 154);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(13, 13);
            this.Label8.TabIndex = 73;
            this.Label8.Text = "6";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st6
            // 
            this.st6.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st6.Location = new System.Drawing.Point(32, 154);
            this.st6.Margin = new System.Windows.Forms.Padding(5);
            this.st6.Name = "st6";
            this.st6.Size = new System.Drawing.Size(70, 22);
            this.st6.TabIndex = 74;
            this.st6.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label9.Location = new System.Drawing.Point(11, 177);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(13, 13);
            this.Label9.TabIndex = 75;
            this.Label9.Text = "7";
            this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st7
            // 
            this.st7.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st7.Location = new System.Drawing.Point(32, 177);
            this.st7.Margin = new System.Windows.Forms.Padding(5);
            this.st7.Name = "st7";
            this.st7.Size = new System.Drawing.Size(70, 22);
            this.st7.TabIndex = 76;
            this.st7.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label10.Location = new System.Drawing.Point(11, 201);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(13, 13);
            this.Label10.TabIndex = 77;
            this.Label10.Text = "8";
            this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st8
            // 
            this.st8.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st8.Location = new System.Drawing.Point(32, 201);
            this.st8.Margin = new System.Windows.Forms.Padding(5);
            this.st8.Name = "st8";
            this.st8.Size = new System.Drawing.Size(70, 22);
            this.st8.TabIndex = 78;
            this.st8.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label11.Location = new System.Drawing.Point(137, 36);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(13, 13);
            this.Label11.TabIndex = 79;
            this.Label11.Text = "9";
            this.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st9
            // 
            this.st9.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st9.Location = new System.Drawing.Point(165, 36);
            this.st9.Margin = new System.Windows.Forms.Padding(5);
            this.st9.Name = "st9";
            this.st9.Size = new System.Drawing.Size(70, 22);
            this.st9.TabIndex = 80;
            this.st9.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label12.Location = new System.Drawing.Point(137, 60);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(19, 13);
            this.Label12.TabIndex = 81;
            this.Label12.Text = "10";
            this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st10
            // 
            this.st10.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st10.Location = new System.Drawing.Point(165, 60);
            this.st10.Margin = new System.Windows.Forms.Padding(5);
            this.st10.Name = "st10";
            this.st10.Size = new System.Drawing.Size(70, 22);
            this.st10.TabIndex = 82;
            this.st10.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label13.Location = new System.Drawing.Point(137, 83);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(19, 13);
            this.Label13.TabIndex = 83;
            this.Label13.Text = "11";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st11
            // 
            this.st11.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st11.Location = new System.Drawing.Point(165, 83);
            this.st11.Margin = new System.Windows.Forms.Padding(5);
            this.st11.Name = "st11";
            this.st11.Size = new System.Drawing.Size(70, 22);
            this.st11.TabIndex = 84;
            this.st11.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label14.Location = new System.Drawing.Point(137, 107);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(19, 13);
            this.Label14.TabIndex = 85;
            this.Label14.Text = "12";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st12
            // 
            this.st12.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st12.Location = new System.Drawing.Point(165, 107);
            this.st12.Margin = new System.Windows.Forms.Padding(5);
            this.st12.Name = "st12";
            this.st12.Size = new System.Drawing.Size(70, 22);
            this.st12.TabIndex = 86;
            this.st12.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label15.Location = new System.Drawing.Point(137, 130);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(19, 13);
            this.Label15.TabIndex = 87;
            this.Label15.Text = "13";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st13
            // 
            this.st13.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st13.Location = new System.Drawing.Point(165, 130);
            this.st13.Margin = new System.Windows.Forms.Padding(5);
            this.st13.Name = "st13";
            this.st13.Size = new System.Drawing.Size(70, 22);
            this.st13.TabIndex = 88;
            this.st13.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label16.Location = new System.Drawing.Point(137, 154);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(19, 13);
            this.Label16.TabIndex = 89;
            this.Label16.Text = "14";
            this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st14
            // 
            this.st14.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st14.Location = new System.Drawing.Point(165, 154);
            this.st14.Margin = new System.Windows.Forms.Padding(5);
            this.st14.Name = "st14";
            this.st14.Size = new System.Drawing.Size(70, 22);
            this.st14.TabIndex = 90;
            this.st14.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label17.Location = new System.Drawing.Point(137, 177);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(19, 13);
            this.Label17.TabIndex = 91;
            this.Label17.Text = "15";
            this.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st15
            // 
            this.st15.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st15.Location = new System.Drawing.Point(165, 177);
            this.st15.Margin = new System.Windows.Forms.Padding(5);
            this.st15.Name = "st15";
            this.st15.Size = new System.Drawing.Size(70, 22);
            this.st15.TabIndex = 92;
            this.st15.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label18.Location = new System.Drawing.Point(137, 201);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(19, 13);
            this.Label18.TabIndex = 93;
            this.Label18.Text = "16";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st16
            // 
            this.st16.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st16.Location = new System.Drawing.Point(165, 201);
            this.st16.Margin = new System.Windows.Forms.Padding(5);
            this.st16.Name = "st16";
            this.st16.Size = new System.Drawing.Size(70, 22);
            this.st16.TabIndex = 94;
            this.st16.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label19.Location = new System.Drawing.Point(263, 36);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(19, 13);
            this.Label19.TabIndex = 95;
            this.Label19.Text = "17";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st17
            // 
            this.st17.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st17.Location = new System.Drawing.Point(293, 33);
            this.st17.Margin = new System.Windows.Forms.Padding(5);
            this.st17.Name = "st17";
            this.st17.Size = new System.Drawing.Size(70, 22);
            this.st17.TabIndex = 96;
            this.st17.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label20.Location = new System.Drawing.Point(263, 60);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(19, 13);
            this.Label20.TabIndex = 97;
            this.Label20.Text = "18";
            this.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st18
            // 
            this.st18.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st18.Location = new System.Drawing.Point(293, 57);
            this.st18.Margin = new System.Windows.Forms.Padding(5);
            this.st18.Name = "st18";
            this.st18.Size = new System.Drawing.Size(70, 22);
            this.st18.TabIndex = 98;
            this.st18.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label21.Location = new System.Drawing.Point(263, 83);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(19, 13);
            this.Label21.TabIndex = 99;
            this.Label21.Text = "19";
            this.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st19
            // 
            this.st19.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st19.Location = new System.Drawing.Point(293, 80);
            this.st19.Margin = new System.Windows.Forms.Padding(5);
            this.st19.Name = "st19";
            this.st19.Size = new System.Drawing.Size(70, 22);
            this.st19.TabIndex = 100;
            this.st19.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label22
            // 
            this.Label22.AutoSize = true;
            this.Label22.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label22.Location = new System.Drawing.Point(263, 107);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(19, 13);
            this.Label22.TabIndex = 101;
            this.Label22.Text = "20";
            this.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st20
            // 
            this.st20.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st20.Location = new System.Drawing.Point(293, 104);
            this.st20.Margin = new System.Windows.Forms.Padding(5);
            this.st20.Name = "st20";
            this.st20.Size = new System.Drawing.Size(70, 22);
            this.st20.TabIndex = 102;
            this.st20.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label23
            // 
            this.Label23.AutoSize = true;
            this.Label23.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label23.Location = new System.Drawing.Point(263, 130);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(19, 13);
            this.Label23.TabIndex = 103;
            this.Label23.Text = "21";
            this.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st21
            // 
            this.st21.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st21.Location = new System.Drawing.Point(293, 128);
            this.st21.Margin = new System.Windows.Forms.Padding(5);
            this.st21.Name = "st21";
            this.st21.Size = new System.Drawing.Size(70, 22);
            this.st21.TabIndex = 104;
            this.st21.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label24.Location = new System.Drawing.Point(263, 154);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(19, 13);
            this.Label24.TabIndex = 105;
            this.Label24.Text = "22";
            this.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st22
            // 
            this.st22.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st22.Location = new System.Drawing.Point(293, 151);
            this.st22.Margin = new System.Windows.Forms.Padding(5);
            this.st22.Name = "st22";
            this.st22.Size = new System.Drawing.Size(70, 22);
            this.st22.TabIndex = 106;
            this.st22.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label25.Location = new System.Drawing.Point(263, 177);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(19, 13);
            this.Label25.TabIndex = 107;
            this.Label25.Text = "23";
            this.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st23
            // 
            this.st23.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st23.Location = new System.Drawing.Point(293, 175);
            this.st23.Margin = new System.Windows.Forms.Padding(5);
            this.st23.Name = "st23";
            this.st23.Size = new System.Drawing.Size(70, 22);
            this.st23.TabIndex = 108;
            this.st23.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Font = new System.Drawing.Font("Tahoma", 8F);
            this.Label26.Location = new System.Drawing.Point(263, 201);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(19, 13);
            this.Label26.TabIndex = 109;
            this.Label26.Text = "24";
            this.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st24
            // 
            this.st24.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.st24.Location = new System.Drawing.Point(293, 198);
            this.st24.Margin = new System.Windows.Forms.Padding(5);
            this.st24.Name = "st24";
            this.st24.Size = new System.Drawing.Size(70, 22);
            this.st24.TabIndex = 110;
            this.st24.Validating += new System.ComponentModel.CancelEventHandler(this.st1_Validating);
            // 
            // chart1
            // 
            this.chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea4.AxisX.Title = "Stunden";
            chartArea4.AxisX.TitleFont = new System.Drawing.Font("Segoe UI", 8F);
            chartArea4.AxisY.Title = "Normierte Stundenwerte";
            chartArea4.AxisY.TitleFont = new System.Drawing.Font("Segoe UI", 8F);
            chartArea4.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea4);
            legend4.Enabled = false;
            legend4.Name = "Legend1";
            this.chart1.Legends.Add(legend4);
            this.chart1.Location = new System.Drawing.Point(33, 426);
            this.chart1.Name = "chart1";
            series4.ChartArea = "ChartArea1";
            series4.Font = new System.Drawing.Font("Segoe UI", 8F);
            series4.IsVisibleInLegend = false;
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chart1.Series.Add(series4);
            this.chart1.Size = new System.Drawing.Size(622, 203);
            this.chart1.TabIndex = 16;
            this.chart1.Text = "chart1";
            // 
            // btn_Loeschen
            // 
            this.btn_Loeschen.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btn_Loeschen.Location = new System.Drawing.Point(557, 114);
            this.btn_Loeschen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Loeschen.Name = "btn_Loeschen";
            this.btn_Loeschen.Size = new System.Drawing.Size(98, 33);
            this.btn_Loeschen.TabIndex = 114;
            this.btn_Loeschen.Text = "Typ L�schen";
            this.btn_Loeschen.UseVisualStyleBackColor = true;
            this.btn_Loeschen.Click += new System.EventHandler(this.btn_Loeschen_Click);
            // 
            // Form_EingGebTyp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 680);
            this.Controls.Add(this.btn_Loeschen);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btn_Speichern);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.textBox_Beschreibung);
            this.Controls.Add(this.btn_EingneuerTyp);
            this.Controls.Add(this.btn_Schliessen);
            this.Controls.Add(this.listBox_Typename);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form_EingGebTyp";
            this.Text = "Geb�udetypen Verwaltung";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

private System.Windows.Forms.Label Label1;
private System.Windows.Forms.Label Label2;
private System.Windows.Forms.TextBox textBox_Beschreibung;
private System.Windows.Forms.Button btn_EingneuerTyp;
private System.Windows.Forms.Button btn_Schliessen;
private System.Windows.Forms.ListBox listBox_Typename;
private System.Windows.Forms.GroupBox groupBox1;
private System.Windows.Forms.Label Label3;
private System.Windows.Forms.TextBox st1;
private System.Windows.Forms.Label Label4;
private System.Windows.Forms.TextBox st2;
private System.Windows.Forms.Label Label5;
private System.Windows.Forms.TextBox st3;
private System.Windows.Forms.Label Label6;
private System.Windows.Forms.TextBox st4;
private System.Windows.Forms.Label Label7;
private System.Windows.Forms.TextBox st5;
private System.Windows.Forms.Label Label8;
private System.Windows.Forms.TextBox st6;
private System.Windows.Forms.Label Label9;
private System.Windows.Forms.TextBox st7;
private System.Windows.Forms.Label Label10;
private System.Windows.Forms.TextBox st8;
private System.Windows.Forms.Label Label11;
private System.Windows.Forms.TextBox st9;
private System.Windows.Forms.Label Label12;
private System.Windows.Forms.TextBox st10;
private System.Windows.Forms.Label Label13;
private System.Windows.Forms.TextBox st11;
private System.Windows.Forms.Label Label14;
private System.Windows.Forms.TextBox st12;
private System.Windows.Forms.Label Label15;
private System.Windows.Forms.TextBox st13;
private System.Windows.Forms.Label Label16;
private System.Windows.Forms.TextBox st14;
private System.Windows.Forms.Label Label17;
private System.Windows.Forms.TextBox st15;
private System.Windows.Forms.Label Label18;
private System.Windows.Forms.TextBox st16;
private System.Windows.Forms.Label Label19;
private System.Windows.Forms.TextBox st17;
private System.Windows.Forms.Label Label20;
private System.Windows.Forms.TextBox st18;
private System.Windows.Forms.Label Label21;
private System.Windows.Forms.TextBox st19;
private System.Windows.Forms.Label Label22;
private System.Windows.Forms.TextBox st20;
private System.Windows.Forms.Label Label23;
private System.Windows.Forms.TextBox st21;
private System.Windows.Forms.Label Label24;
private System.Windows.Forms.TextBox st22;
private System.Windows.Forms.Label Label25;
private System.Windows.Forms.TextBox st23;
private System.Windows.Forms.Label Label26;
private System.Windows.Forms.TextBox st24;
private System.Windows.Forms.ListBox listBox_Kurve;
private System.Windows.Forms.Label Label27;
private System.Windows.Forms.Button btn_Speichern;
private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
private System.Windows.Forms.Button btn_Loeschen;


 
    }
}