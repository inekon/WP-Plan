namespace WindowsFormsApplication1
{
    partial class Form_Gebaeude2
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gel�scht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode f�r die Designerunterst�tzung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Hilfe = new System.Windows.Forms.Button();
            this.btn_Speichern = new System.Windows.Forms.Button();
            this.btn_Abbrechen = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.textBox_SollTag = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.textBox_NachtAbsenkung = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.textBox_MaxTemperatur = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.textBox_WEAbsenkung = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.textBox_SollFerien = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.textBox_WBVK_Fenster = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.textBox_WBVK_Keller = new System.Windows.Forms.TextBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.textBox_WBVK_Dach = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Label49 = new System.Windows.Forms.Label();
            this.textBox_AnschussFenster = new System.Windows.Forms.TextBox();
            this.Label50 = new System.Windows.Forms.Label();
            this.textBox_AnschussDach = new System.Windows.Forms.TextBox();
            this.Label51 = new System.Windows.Forms.Label();
            this.textBox_AnschussKeller = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Label33 = new System.Windows.Forms.Label();
            this.Winter_Tag_A = new System.Windows.Forms.TextBox();
            this.Ostern_Tag_A = new System.Windows.Forms.TextBox();
            this.Label34 = new System.Windows.Forms.Label();
            this.Label35 = new System.Windows.Forms.Label();
            this.Sommer_Tag_A = new System.Windows.Forms.TextBox();
            this.Herbst_Tag_A = new System.Windows.Forms.TextBox();
            this.Label36 = new System.Windows.Forms.Label();
            this.Winter_Monat_A = new System.Windows.Forms.TextBox();
            this.Ostern_Monat_A = new System.Windows.Forms.TextBox();
            this.Sommer_Monat_A = new System.Windows.Forms.TextBox();
            this.Herbst_Monat_A = new System.Windows.Forms.TextBox();
            this.Label37 = new System.Windows.Forms.Label();
            this.Label38 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Label52 = new System.Windows.Forms.Label();
            this.Winter_Tag_E = new System.Windows.Forms.TextBox();
            this.Ostern_Tag_E = new System.Windows.Forms.TextBox();
            this.Label53 = new System.Windows.Forms.Label();
            this.Label54 = new System.Windows.Forms.Label();
            this.Sommer_Tag_E = new System.Windows.Forms.TextBox();
            this.Herbst_Tag_E = new System.Windows.Forms.TextBox();
            this.Label55 = new System.Windows.Forms.Label();
            this.Winter_Monat_E = new System.Windows.Forms.TextBox();
            this.Ostern_Monat_E = new System.Windows.Forms.TextBox();
            this.Sommer_Monat_E = new System.Windows.Forms.TextBox();
            this.Herbst_Monat_E = new System.Windows.Forms.TextBox();
            this.Label56 = new System.Windows.Forms.Label();
            this.Label57 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Label45 = new System.Windows.Forms.Label();
            this.textBox_Luftwechsel = new System.Windows.Forms.TextBox();
            this.textBox_WWNutzer = new System.Windows.Forms.TextBox();
            this.Label46 = new System.Windows.Forms.Label();
            this.Label47 = new System.Windows.Forms.Label();
            this.Label48 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Hilfe
            // 
            this.btn_Hilfe.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Hilfe.Location = new System.Drawing.Point(31, 547);
            this.btn_Hilfe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Hilfe.Name = "btn_Hilfe";
            this.btn_Hilfe.Size = new System.Drawing.Size(91, 31);
            this.btn_Hilfe.TabIndex = 0;
            this.btn_Hilfe.Text = "Hilfe";
            this.btn_Hilfe.UseVisualStyleBackColor = true;
            // 
            // btn_Speichern
            // 
            this.btn_Speichern.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Speichern.Location = new System.Drawing.Point(499, 547);
            this.btn_Speichern.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Speichern.Name = "btn_Speichern";
            this.btn_Speichern.Size = new System.Drawing.Size(91, 31);
            this.btn_Speichern.TabIndex = 1;
            this.btn_Speichern.Text = "OK";
            this.btn_Speichern.UseVisualStyleBackColor = true;
            this.btn_Speichern.Click += new System.EventHandler(this.btn_Speichern_Click);
            // 
            // btn_Abbrechen
            // 
            this.btn_Abbrechen.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_Abbrechen.Location = new System.Drawing.Point(401, 547);
            this.btn_Abbrechen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Abbrechen.Name = "btn_Abbrechen";
            this.btn_Abbrechen.Size = new System.Drawing.Size(91, 31);
            this.btn_Abbrechen.TabIndex = 4;
            this.btn_Abbrechen.Text = "Abbrechen";
            this.btn_Abbrechen.UseVisualStyleBackColor = true;
            this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Label4);
            this.groupBox1.Controls.Add(this.textBox_SollTag);
            this.groupBox1.Controls.Add(this.Label5);
            this.groupBox1.Controls.Add(this.textBox_NachtAbsenkung);
            this.groupBox1.Controls.Add(this.Label6);
            this.groupBox1.Controls.Add(this.textBox_MaxTemperatur);
            this.groupBox1.Controls.Add(this.Label8);
            this.groupBox1.Controls.Add(this.Label9);
            this.groupBox1.Controls.Add(this.Label10);
            this.groupBox1.Controls.Add(this.Label12);
            this.groupBox1.Controls.Add(this.textBox_WEAbsenkung);
            this.groupBox1.Controls.Add(this.Label13);
            this.groupBox1.Controls.Add(this.textBox_SollFerien);
            this.groupBox1.Controls.Add(this.Label14);
            this.groupBox1.Controls.Add(this.Label15);
            this.groupBox1.Location = new System.Drawing.Point(14, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(536, 118);
            this.groupBox1.TabIndex = 67;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Raumtemperaturen";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label4.Location = new System.Drawing.Point(21, 28);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(75, 15);
            this.Label4.TabIndex = 21;
            this.Label4.Text = "Soll am Tag :";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_SollTag
            // 
            this.textBox_SollTag.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_SollTag.Location = new System.Drawing.Point(166, 26);
            this.textBox_SollTag.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_SollTag.Name = "textBox_SollTag";
            this.textBox_SollTag.Size = new System.Drawing.Size(56, 23);
            this.textBox_SollTag.TabIndex = 22;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label5.Location = new System.Drawing.Point(21, 58);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(123, 15);
            this.Label5.TabIndex = 23;
            this.Label5.Text = "Nachtabsenkung auf :";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_NachtAbsenkung
            // 
            this.textBox_NachtAbsenkung.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_NachtAbsenkung.Location = new System.Drawing.Point(166, 56);
            this.textBox_NachtAbsenkung.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_NachtAbsenkung.Name = "textBox_NachtAbsenkung";
            this.textBox_NachtAbsenkung.Size = new System.Drawing.Size(56, 23);
            this.textBox_NachtAbsenkung.TabIndex = 24;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label6.Location = new System.Drawing.Point(21, 88);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(145, 15);
            this.Label6.TabIndex = 25;
            this.Label6.Text = "Maximalraumtemperatur :";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MaxTemperatur
            // 
            this.textBox_MaxTemperatur.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_MaxTemperatur.Location = new System.Drawing.Point(166, 86);
            this.textBox_MaxTemperatur.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_MaxTemperatur.Name = "textBox_MaxTemperatur";
            this.textBox_MaxTemperatur.Size = new System.Drawing.Size(56, 23);
            this.textBox_MaxTemperatur.TabIndex = 26;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.BackColor = System.Drawing.Color.Black;
            this.Label8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(230, 28);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(23, 15);
            this.Label8.TabIndex = 27;
            this.Label8.Text = "�C ";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.BackColor = System.Drawing.Color.Black;
            this.Label9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(230, 58);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(23, 15);
            this.Label9.TabIndex = 28;
            this.Label9.Text = "�C ";
            this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.BackColor = System.Drawing.Color.Black;
            this.Label10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label10.ForeColor = System.Drawing.Color.White;
            this.Label10.Location = new System.Drawing.Point(230, 88);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(23, 15);
            this.Label10.TabIndex = 29;
            this.Label10.Text = "�C ";
            this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label12.Location = new System.Drawing.Point(279, 28);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(135, 15);
            this.Label12.TabIndex = 30;
            this.Label12.Text = "Wochenendabsenkung :";
            this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_WEAbsenkung
            // 
            this.textBox_WEAbsenkung.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_WEAbsenkung.Location = new System.Drawing.Point(420, 28);
            this.textBox_WEAbsenkung.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_WEAbsenkung.Name = "textBox_WEAbsenkung";
            this.textBox_WEAbsenkung.Size = new System.Drawing.Size(56, 23);
            this.textBox_WEAbsenkung.TabIndex = 31;
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label13.Location = new System.Drawing.Point(279, 58);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(80, 15);
            this.Label13.TabIndex = 32;
            this.Label13.Text = "Soll in Ferien :";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_SollFerien
            // 
            this.textBox_SollFerien.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_SollFerien.Location = new System.Drawing.Point(420, 58);
            this.textBox_SollFerien.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_SollFerien.Name = "textBox_SollFerien";
            this.textBox_SollFerien.Size = new System.Drawing.Size(56, 23);
            this.textBox_SollFerien.TabIndex = 33;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.BackColor = System.Drawing.Color.Black;
            this.Label14.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label14.ForeColor = System.Drawing.Color.White;
            this.Label14.Location = new System.Drawing.Point(481, 28);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(27, 19);
            this.Label14.TabIndex = 34;
            this.Label14.Text = "�C ";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.BackColor = System.Drawing.Color.Black;
            this.Label15.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label15.ForeColor = System.Drawing.Color.White;
            this.Label15.Location = new System.Drawing.Point(481, 58);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(27, 19);
            this.Label15.TabIndex = 35;
            this.Label15.Text = "�C ";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Label17);
            this.groupBox2.Controls.Add(this.textBox_WBVK_Fenster);
            this.groupBox2.Controls.Add(this.Label18);
            this.groupBox2.Controls.Add(this.textBox_WBVK_Keller);
            this.groupBox2.Controls.Add(this.Label23);
            this.groupBox2.Controls.Add(this.textBox_WBVK_Dach);
            this.groupBox2.Location = new System.Drawing.Point(14, 135);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(536, 89);
            this.groupBox2.TabIndex = 68;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "W�rmebr�ckenverlustkoeffizienten [W/(mK)]";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label17.Location = new System.Drawing.Point(21, 27);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(87, 15);
            this.Label17.TabIndex = 33;
            this.Label17.Text = "Fenster-Wand :";
            this.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_WBVK_Fenster
            // 
            this.textBox_WBVK_Fenster.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_WBVK_Fenster.Location = new System.Drawing.Point(166, 25);
            this.textBox_WBVK_Fenster.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_WBVK_Fenster.Name = "textBox_WBVK_Fenster";
            this.textBox_WBVK_Fenster.Size = new System.Drawing.Size(56, 23);
            this.textBox_WBVK_Fenster.TabIndex = 34;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label18.Location = new System.Drawing.Point(21, 59);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(111, 15);
            this.Label18.TabIndex = 35;
            this.Label18.Text = "Au�enwand-Keller :";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_WBVK_Keller
            // 
            this.textBox_WBVK_Keller.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_WBVK_Keller.Location = new System.Drawing.Point(166, 57);
            this.textBox_WBVK_Keller.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_WBVK_Keller.Name = "textBox_WBVK_Keller";
            this.textBox_WBVK_Keller.Size = new System.Drawing.Size(56, 23);
            this.textBox_WBVK_Keller.TabIndex = 36;
            // 
            // Label23
            // 
            this.Label23.AutoSize = true;
            this.Label23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label23.Location = new System.Drawing.Point(307, 27);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(76, 15);
            this.Label23.TabIndex = 37;
            this.Label23.Text = "Wand-Dach :";
            this.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_WBVK_Dach
            // 
            this.textBox_WBVK_Dach.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_WBVK_Dach.Location = new System.Drawing.Point(420, 27);
            this.textBox_WBVK_Dach.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_WBVK_Dach.Name = "textBox_WBVK_Dach";
            this.textBox_WBVK_Dach.Size = new System.Drawing.Size(56, 23);
            this.textBox_WBVK_Dach.TabIndex = 38;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Label49);
            this.groupBox3.Controls.Add(this.textBox_AnschussFenster);
            this.groupBox3.Controls.Add(this.Label50);
            this.groupBox3.Controls.Add(this.textBox_AnschussDach);
            this.groupBox3.Controls.Add(this.Label51);
            this.groupBox3.Controls.Add(this.textBox_AnschussKeller);
            this.groupBox3.Location = new System.Drawing.Point(14, 233);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(536, 92);
            this.groupBox3.TabIndex = 69;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Abmessung Anschlu� [m]";
            // 
            // Label49
            // 
            this.Label49.AutoSize = true;
            this.Label49.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label49.Location = new System.Drawing.Point(21, 26);
            this.Label49.Name = "Label49";
            this.Label49.Size = new System.Drawing.Size(87, 15);
            this.Label49.TabIndex = 45;
            this.Label49.Text = "Fenster-Wand :";
            this.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_AnschussFenster
            // 
            this.textBox_AnschussFenster.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_AnschussFenster.Location = new System.Drawing.Point(166, 24);
            this.textBox_AnschussFenster.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_AnschussFenster.Name = "textBox_AnschussFenster";
            this.textBox_AnschussFenster.Size = new System.Drawing.Size(56, 23);
            this.textBox_AnschussFenster.TabIndex = 46;
            // 
            // Label50
            // 
            this.Label50.AutoSize = true;
            this.Label50.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label50.Location = new System.Drawing.Point(307, 26);
            this.Label50.Name = "Label50";
            this.Label50.Size = new System.Drawing.Size(76, 15);
            this.Label50.TabIndex = 47;
            this.Label50.Text = "Wand-Dach :";
            this.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_AnschussDach
            // 
            this.textBox_AnschussDach.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_AnschussDach.Location = new System.Drawing.Point(420, 26);
            this.textBox_AnschussDach.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_AnschussDach.Name = "textBox_AnschussDach";
            this.textBox_AnschussDach.Size = new System.Drawing.Size(56, 23);
            this.textBox_AnschussDach.TabIndex = 48;
            // 
            // Label51
            // 
            this.Label51.AutoSize = true;
            this.Label51.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label51.Location = new System.Drawing.Point(21, 58);
            this.Label51.Name = "Label51";
            this.Label51.Size = new System.Drawing.Size(111, 15);
            this.Label51.TabIndex = 49;
            this.Label51.Text = "Au�enwand-Keller :";
            this.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_AnschussKeller
            // 
            this.textBox_AnschussKeller.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_AnschussKeller.Location = new System.Drawing.Point(166, 56);
            this.textBox_AnschussKeller.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_AnschussKeller.Name = "textBox_AnschussKeller";
            this.textBox_AnschussKeller.Size = new System.Drawing.Size(56, 23);
            this.textBox_AnschussKeller.TabIndex = 50;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Label33);
            this.groupBox5.Controls.Add(this.Winter_Tag_A);
            this.groupBox5.Controls.Add(this.Ostern_Tag_A);
            this.groupBox5.Controls.Add(this.Label34);
            this.groupBox5.Controls.Add(this.Label35);
            this.groupBox5.Controls.Add(this.Sommer_Tag_A);
            this.groupBox5.Controls.Add(this.Herbst_Tag_A);
            this.groupBox5.Controls.Add(this.Label36);
            this.groupBox5.Controls.Add(this.Winter_Monat_A);
            this.groupBox5.Controls.Add(this.Ostern_Monat_A);
            this.groupBox5.Controls.Add(this.Sommer_Monat_A);
            this.groupBox5.Controls.Add(this.Herbst_Monat_A);
            this.groupBox5.Controls.Add(this.Label37);
            this.groupBox5.Controls.Add(this.Label38);
            this.groupBox5.Location = new System.Drawing.Point(14, 338);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(222, 188);
            this.groupBox5.TabIndex = 71;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Ferien Anfang";
            // 
            // Label33
            // 
            this.Label33.AutoSize = true;
            this.Label33.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label33.Location = new System.Drawing.Point(20, 51);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(48, 15);
            this.Label33.TabIndex = 47;
            this.Label33.Text = "Winter :";
            this.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Winter_Tag_A
            // 
            this.Winter_Tag_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Winter_Tag_A.Location = new System.Drawing.Point(76, 51);
            this.Winter_Tag_A.Margin = new System.Windows.Forms.Padding(5);
            this.Winter_Tag_A.Name = "Winter_Tag_A";
            this.Winter_Tag_A.Size = new System.Drawing.Size(56, 23);
            this.Winter_Tag_A.TabIndex = 48;
            // 
            // Ostern_Tag_A
            // 
            this.Ostern_Tag_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Ostern_Tag_A.Location = new System.Drawing.Point(76, 83);
            this.Ostern_Tag_A.Margin = new System.Windows.Forms.Padding(5);
            this.Ostern_Tag_A.Name = "Ostern_Tag_A";
            this.Ostern_Tag_A.Size = new System.Drawing.Size(56, 23);
            this.Ostern_Tag_A.TabIndex = 49;
            // 
            // Label34
            // 
            this.Label34.AutoSize = true;
            this.Label34.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label34.Location = new System.Drawing.Point(20, 83);
            this.Label34.Name = "Label34";
            this.Label34.Size = new System.Drawing.Size(48, 15);
            this.Label34.TabIndex = 50;
            this.Label34.Text = "Ostern :";
            this.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label35
            // 
            this.Label35.AutoSize = true;
            this.Label35.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label35.Location = new System.Drawing.Point(20, 114);
            this.Label35.Name = "Label35";
            this.Label35.Size = new System.Drawing.Size(58, 15);
            this.Label35.TabIndex = 51;
            this.Label35.Text = "Sommer :";
            this.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sommer_Tag_A
            // 
            this.Sommer_Tag_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Sommer_Tag_A.Location = new System.Drawing.Point(76, 114);
            this.Sommer_Tag_A.Margin = new System.Windows.Forms.Padding(5);
            this.Sommer_Tag_A.Name = "Sommer_Tag_A";
            this.Sommer_Tag_A.Size = new System.Drawing.Size(56, 23);
            this.Sommer_Tag_A.TabIndex = 52;
            // 
            // Herbst_Tag_A
            // 
            this.Herbst_Tag_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Herbst_Tag_A.Location = new System.Drawing.Point(76, 146);
            this.Herbst_Tag_A.Margin = new System.Windows.Forms.Padding(5);
            this.Herbst_Tag_A.Name = "Herbst_Tag_A";
            this.Herbst_Tag_A.Size = new System.Drawing.Size(56, 23);
            this.Herbst_Tag_A.TabIndex = 53;
            // 
            // Label36
            // 
            this.Label36.AutoSize = true;
            this.Label36.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label36.Location = new System.Drawing.Point(20, 146);
            this.Label36.Name = "Label36";
            this.Label36.Size = new System.Drawing.Size(48, 15);
            this.Label36.TabIndex = 54;
            this.Label36.Text = "Herbst :";
            this.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Winter_Monat_A
            // 
            this.Winter_Monat_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Winter_Monat_A.Location = new System.Drawing.Point(146, 51);
            this.Winter_Monat_A.Margin = new System.Windows.Forms.Padding(5);
            this.Winter_Monat_A.Name = "Winter_Monat_A";
            this.Winter_Monat_A.Size = new System.Drawing.Size(56, 23);
            this.Winter_Monat_A.TabIndex = 55;
            // 
            // Ostern_Monat_A
            // 
            this.Ostern_Monat_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Ostern_Monat_A.Location = new System.Drawing.Point(146, 83);
            this.Ostern_Monat_A.Margin = new System.Windows.Forms.Padding(5);
            this.Ostern_Monat_A.Name = "Ostern_Monat_A";
            this.Ostern_Monat_A.Size = new System.Drawing.Size(56, 23);
            this.Ostern_Monat_A.TabIndex = 56;
            // 
            // Sommer_Monat_A
            // 
            this.Sommer_Monat_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Sommer_Monat_A.Location = new System.Drawing.Point(146, 114);
            this.Sommer_Monat_A.Margin = new System.Windows.Forms.Padding(5);
            this.Sommer_Monat_A.Name = "Sommer_Monat_A";
            this.Sommer_Monat_A.Size = new System.Drawing.Size(56, 23);
            this.Sommer_Monat_A.TabIndex = 57;
            // 
            // Herbst_Monat_A
            // 
            this.Herbst_Monat_A.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Herbst_Monat_A.Location = new System.Drawing.Point(146, 146);
            this.Herbst_Monat_A.Margin = new System.Windows.Forms.Padding(5);
            this.Herbst_Monat_A.Name = "Herbst_Monat_A";
            this.Herbst_Monat_A.Size = new System.Drawing.Size(56, 23);
            this.Herbst_Monat_A.TabIndex = 58;
            // 
            // Label37
            // 
            this.Label37.AutoSize = true;
            this.Label37.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label37.Location = new System.Drawing.Point(84, 31);
            this.Label37.Name = "Label37";
            this.Label37.Size = new System.Drawing.Size(33, 15);
            this.Label37.TabIndex = 59;
            this.Label37.Text = "Tag :";
            this.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label38
            // 
            this.Label38.AutoSize = true;
            this.Label38.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label38.Location = new System.Drawing.Point(154, 31);
            this.Label38.Name = "Label38";
            this.Label38.Size = new System.Drawing.Size(48, 15);
            this.Label38.TabIndex = 60;
            this.Label38.Text = "Monat :";
            this.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Label52);
            this.groupBox6.Controls.Add(this.Winter_Tag_E);
            this.groupBox6.Controls.Add(this.Ostern_Tag_E);
            this.groupBox6.Controls.Add(this.Label53);
            this.groupBox6.Controls.Add(this.Label54);
            this.groupBox6.Controls.Add(this.Sommer_Tag_E);
            this.groupBox6.Controls.Add(this.Herbst_Tag_E);
            this.groupBox6.Controls.Add(this.Label55);
            this.groupBox6.Controls.Add(this.Winter_Monat_E);
            this.groupBox6.Controls.Add(this.Ostern_Monat_E);
            this.groupBox6.Controls.Add(this.Sommer_Monat_E);
            this.groupBox6.Controls.Add(this.Herbst_Monat_E);
            this.groupBox6.Controls.Add(this.Label56);
            this.groupBox6.Controls.Add(this.Label57);
            this.groupBox6.Location = new System.Drawing.Point(247, 338);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(206, 188);
            this.groupBox6.TabIndex = 72;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Ferien Ende";
            // 
            // Label52
            // 
            this.Label52.AutoSize = true;
            this.Label52.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label52.Location = new System.Drawing.Point(13, 54);
            this.Label52.Name = "Label52";
            this.Label52.Size = new System.Drawing.Size(48, 15);
            this.Label52.TabIndex = 61;
            this.Label52.Text = "Winter :";
            this.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Winter_Tag_E
            // 
            this.Winter_Tag_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Winter_Tag_E.Location = new System.Drawing.Point(72, 52);
            this.Winter_Tag_E.Margin = new System.Windows.Forms.Padding(5);
            this.Winter_Tag_E.Name = "Winter_Tag_E";
            this.Winter_Tag_E.Size = new System.Drawing.Size(56, 23);
            this.Winter_Tag_E.TabIndex = 62;
            // 
            // Ostern_Tag_E
            // 
            this.Ostern_Tag_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Ostern_Tag_E.Location = new System.Drawing.Point(72, 84);
            this.Ostern_Tag_E.Margin = new System.Windows.Forms.Padding(5);
            this.Ostern_Tag_E.Name = "Ostern_Tag_E";
            this.Ostern_Tag_E.Size = new System.Drawing.Size(56, 23);
            this.Ostern_Tag_E.TabIndex = 63;
            // 
            // Label53
            // 
            this.Label53.AutoSize = true;
            this.Label53.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label53.Location = new System.Drawing.Point(13, 86);
            this.Label53.Name = "Label53";
            this.Label53.Size = new System.Drawing.Size(48, 15);
            this.Label53.TabIndex = 64;
            this.Label53.Text = "Ostern :";
            this.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label54
            // 
            this.Label54.AutoSize = true;
            this.Label54.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label54.Location = new System.Drawing.Point(13, 117);
            this.Label54.Name = "Label54";
            this.Label54.Size = new System.Drawing.Size(58, 15);
            this.Label54.TabIndex = 65;
            this.Label54.Text = "Sommer :";
            this.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sommer_Tag_E
            // 
            this.Sommer_Tag_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Sommer_Tag_E.Location = new System.Drawing.Point(72, 115);
            this.Sommer_Tag_E.Margin = new System.Windows.Forms.Padding(5);
            this.Sommer_Tag_E.Name = "Sommer_Tag_E";
            this.Sommer_Tag_E.Size = new System.Drawing.Size(56, 23);
            this.Sommer_Tag_E.TabIndex = 66;
            // 
            // Herbst_Tag_E
            // 
            this.Herbst_Tag_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Herbst_Tag_E.Location = new System.Drawing.Point(72, 147);
            this.Herbst_Tag_E.Margin = new System.Windows.Forms.Padding(5);
            this.Herbst_Tag_E.Name = "Herbst_Tag_E";
            this.Herbst_Tag_E.Size = new System.Drawing.Size(56, 23);
            this.Herbst_Tag_E.TabIndex = 67;
            // 
            // Label55
            // 
            this.Label55.AutoSize = true;
            this.Label55.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label55.Location = new System.Drawing.Point(13, 149);
            this.Label55.Name = "Label55";
            this.Label55.Size = new System.Drawing.Size(48, 15);
            this.Label55.TabIndex = 68;
            this.Label55.Text = "Herbst :";
            this.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Winter_Monat_E
            // 
            this.Winter_Monat_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Winter_Monat_E.Location = new System.Drawing.Point(142, 52);
            this.Winter_Monat_E.Margin = new System.Windows.Forms.Padding(5);
            this.Winter_Monat_E.Name = "Winter_Monat_E";
            this.Winter_Monat_E.Size = new System.Drawing.Size(56, 23);
            this.Winter_Monat_E.TabIndex = 69;
            // 
            // Ostern_Monat_E
            // 
            this.Ostern_Monat_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Ostern_Monat_E.Location = new System.Drawing.Point(142, 84);
            this.Ostern_Monat_E.Margin = new System.Windows.Forms.Padding(5);
            this.Ostern_Monat_E.Name = "Ostern_Monat_E";
            this.Ostern_Monat_E.Size = new System.Drawing.Size(56, 23);
            this.Ostern_Monat_E.TabIndex = 70;
            // 
            // Sommer_Monat_E
            // 
            this.Sommer_Monat_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Sommer_Monat_E.Location = new System.Drawing.Point(142, 115);
            this.Sommer_Monat_E.Margin = new System.Windows.Forms.Padding(5);
            this.Sommer_Monat_E.Name = "Sommer_Monat_E";
            this.Sommer_Monat_E.Size = new System.Drawing.Size(56, 23);
            this.Sommer_Monat_E.TabIndex = 71;
            // 
            // Herbst_Monat_E
            // 
            this.Herbst_Monat_E.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Herbst_Monat_E.Location = new System.Drawing.Point(142, 147);
            this.Herbst_Monat_E.Margin = new System.Windows.Forms.Padding(5);
            this.Herbst_Monat_E.Name = "Herbst_Monat_E";
            this.Herbst_Monat_E.Size = new System.Drawing.Size(56, 23);
            this.Herbst_Monat_E.TabIndex = 72;
            // 
            // Label56
            // 
            this.Label56.AutoSize = true;
            this.Label56.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label56.Location = new System.Drawing.Point(80, 32);
            this.Label56.Name = "Label56";
            this.Label56.Size = new System.Drawing.Size(33, 15);
            this.Label56.TabIndex = 73;
            this.Label56.Text = "Tag :";
            this.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label57
            // 
            this.Label57.AutoSize = true;
            this.Label57.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label57.Location = new System.Drawing.Point(150, 32);
            this.Label57.Name = "Label57";
            this.Label57.Size = new System.Drawing.Size(48, 15);
            this.Label57.TabIndex = 74;
            this.Label57.Text = "Monat :";
            this.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Label45);
            this.groupBox7.Controls.Add(this.textBox_Luftwechsel);
            this.groupBox7.Controls.Add(this.textBox_WWNutzer);
            this.groupBox7.Controls.Add(this.Label46);
            this.groupBox7.Controls.Add(this.Label47);
            this.groupBox7.Controls.Add(this.Label48);
            this.groupBox7.Location = new System.Drawing.Point(465, 338);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(135, 188);
            this.groupBox7.TabIndex = 73;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Sonstiges";
            // 
            // Label45
            // 
            this.Label45.AutoSize = true;
            this.Label45.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label45.Location = new System.Drawing.Point(10, 36);
            this.Label45.Name = "Label45";
            this.Label45.Size = new System.Drawing.Size(96, 15);
            this.Label45.TabIndex = 67;
            this.Label45.Text = "Luftwechselrate :";
            this.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Luftwechsel
            // 
            this.textBox_Luftwechsel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_Luftwechsel.Location = new System.Drawing.Point(13, 54);
            this.textBox_Luftwechsel.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Luftwechsel.Name = "textBox_Luftwechsel";
            this.textBox_Luftwechsel.Size = new System.Drawing.Size(56, 23);
            this.textBox_Luftwechsel.TabIndex = 68;
            // 
            // textBox_WWNutzer
            // 
            this.textBox_WWNutzer.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox_WWNutzer.Location = new System.Drawing.Point(13, 109);
            this.textBox_WWNutzer.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_WWNutzer.Name = "textBox_WWNutzer";
            this.textBox_WWNutzer.Size = new System.Drawing.Size(56, 23);
            this.textBox_WWNutzer.TabIndex = 69;
            // 
            // Label46
            // 
            this.Label46.AutoSize = true;
            this.Label46.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label46.Location = new System.Drawing.Point(10, 91);
            this.Label46.Name = "Label46";
            this.Label46.Size = new System.Drawing.Size(114, 15);
            this.Label46.TabIndex = 70;
            this.Label46.Text = "WW-Bedarf/Nutzer :";
            this.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label47
            // 
            this.Label47.AutoSize = true;
            this.Label47.BackColor = System.Drawing.Color.Black;
            this.Label47.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label47.ForeColor = System.Drawing.Color.White;
            this.Label47.Location = new System.Drawing.Point(76, 54);
            this.Label47.Name = "Label47";
            this.Label47.Size = new System.Drawing.Size(25, 15);
            this.Label47.TabIndex = 71;
            this.Label47.Text = "1/h";
            this.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label48
            // 
            this.Label48.AutoSize = true;
            this.Label48.BackColor = System.Drawing.Color.Black;
            this.Label48.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Label48.ForeColor = System.Drawing.Color.White;
            this.Label48.Location = new System.Drawing.Point(76, 109);
            this.Label48.Name = "Label48";
            this.Label48.Size = new System.Drawing.Size(42, 15);
            this.Label48.TabIndex = 72;
            this.Label48.Text = "kWh/a";
            this.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form_Gebaeude2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 591);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_Hilfe);
            this.Controls.Add(this.btn_Speichern);
            this.Controls.Add(this.btn_Abbrechen);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form_Gebaeude2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

private System.Windows.Forms.Button btn_Hilfe;
private System.Windows.Forms.Button btn_Speichern;
private System.Windows.Forms.Button btn_Abbrechen;
private System.Windows.Forms.GroupBox groupBox1;
private System.Windows.Forms.Label Label4;
private System.Windows.Forms.TextBox textBox_SollTag;
private System.Windows.Forms.Label Label5;
private System.Windows.Forms.TextBox textBox_NachtAbsenkung;
private System.Windows.Forms.Label Label6;
private System.Windows.Forms.TextBox textBox_MaxTemperatur;
private System.Windows.Forms.Label Label8;
private System.Windows.Forms.Label Label9;
private System.Windows.Forms.Label Label10;
private System.Windows.Forms.Label Label12;
private System.Windows.Forms.TextBox textBox_WEAbsenkung;
private System.Windows.Forms.Label Label13;
private System.Windows.Forms.TextBox textBox_SollFerien;
private System.Windows.Forms.Label Label14;
private System.Windows.Forms.Label Label15;
private System.Windows.Forms.GroupBox groupBox2;
private System.Windows.Forms.Label Label17;
private System.Windows.Forms.TextBox textBox_WBVK_Fenster;
private System.Windows.Forms.Label Label18;
private System.Windows.Forms.TextBox textBox_WBVK_Keller;
private System.Windows.Forms.Label Label23;
private System.Windows.Forms.TextBox textBox_WBVK_Dach;
private System.Windows.Forms.GroupBox groupBox3;
private System.Windows.Forms.Label Label49;
private System.Windows.Forms.TextBox textBox_AnschussFenster;
private System.Windows.Forms.Label Label50;
private System.Windows.Forms.TextBox textBox_AnschussDach;
private System.Windows.Forms.Label Label51;
private System.Windows.Forms.TextBox textBox_AnschussKeller;
private System.Windows.Forms.GroupBox groupBox5;
private System.Windows.Forms.Label Label33;
private System.Windows.Forms.TextBox Winter_Tag_A;
private System.Windows.Forms.TextBox Ostern_Tag_A;
private System.Windows.Forms.Label Label34;
private System.Windows.Forms.Label Label35;
private System.Windows.Forms.TextBox Sommer_Tag_A;
private System.Windows.Forms.TextBox Herbst_Tag_A;
private System.Windows.Forms.Label Label36;
private System.Windows.Forms.TextBox Winter_Monat_A;
private System.Windows.Forms.TextBox Ostern_Monat_A;
private System.Windows.Forms.TextBox Sommer_Monat_A;
private System.Windows.Forms.TextBox Herbst_Monat_A;
private System.Windows.Forms.Label Label37;
private System.Windows.Forms.Label Label38;
private System.Windows.Forms.GroupBox groupBox6;
private System.Windows.Forms.Label Label52;
private System.Windows.Forms.TextBox Winter_Tag_E;
private System.Windows.Forms.TextBox Ostern_Tag_E;
private System.Windows.Forms.Label Label53;
private System.Windows.Forms.Label Label54;
private System.Windows.Forms.TextBox Sommer_Tag_E;
private System.Windows.Forms.TextBox Herbst_Tag_E;
private System.Windows.Forms.Label Label55;
private System.Windows.Forms.TextBox Winter_Monat_E;
private System.Windows.Forms.TextBox Ostern_Monat_E;
private System.Windows.Forms.TextBox Sommer_Monat_E;
private System.Windows.Forms.TextBox Herbst_Monat_E;
private System.Windows.Forms.Label Label56;
private System.Windows.Forms.Label Label57;
private System.Windows.Forms.GroupBox groupBox7;
private System.Windows.Forms.Label Label45;
private System.Windows.Forms.TextBox textBox_Luftwechsel;
private System.Windows.Forms.TextBox textBox_WWNutzer;
private System.Windows.Forms.Label Label46;
private System.Windows.Forms.Label Label47;
private System.Windows.Forms.Label Label48;


 
    }
}