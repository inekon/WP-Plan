namespace WindowsFormsApplication1
{
    partial class Form_EingDBStromverbraucher 
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gel�scht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode f�r die Designerunterst�tzung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.comboBox_Stromtyp = new System.Windows.Forms.ComboBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.textBox_Beschreibung = new System.Windows.Forms.TextBox();
            this.btn_Speichern = new System.Windows.Forms.Button();
            this.btn_Speichern_Unter = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_Ueberschreiben = new System.Windows.Forms.Button();
            this.textBox_Stromname = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Wert1 = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Wert2 = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Wert3 = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Wert4 = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Wert5 = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.Wert8 = new System.Windows.Forms.TextBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.Wert7 = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.Label20 = new System.Windows.Forms.Label();
            this.Wert9 = new System.Windows.Forms.TextBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.Label22 = new System.Windows.Forms.Label();
            this.Wert10 = new System.Windows.Forms.TextBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.Wert11 = new System.Windows.Forms.TextBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.Wert12 = new System.Windows.Forms.TextBox();
            this.Label26 = new System.Windows.Forms.Label();
            this.Label27 = new System.Windows.Forms.Label();
            this.Wert6 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label1.Location = new System.Drawing.Point(59, 33);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(48, 19);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Name:";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label2.Location = new System.Drawing.Point(342, 31);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(107, 19);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Verbrauchertyp:";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox_Stromtyp
            // 
            this.comboBox_Stromtyp.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.comboBox_Stromtyp.Location = new System.Drawing.Point(455, 31);
            this.comboBox_Stromtyp.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.comboBox_Stromtyp.Name = "comboBox_Stromtyp";
            this.comboBox_Stromtyp.Size = new System.Drawing.Size(192, 25);
            this.comboBox_Stromtyp.TabIndex = 3;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label3.Location = new System.Drawing.Point(13, 76);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(94, 19);
            this.Label3.TabIndex = 4;
            this.Label3.Text = "Beschreibung:";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Beschreibung
            // 
            this.textBox_Beschreibung.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_Beschreibung.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox_Beschreibung.Location = new System.Drawing.Point(115, 73);
            this.textBox_Beschreibung.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Beschreibung.Multiline = true;
            this.textBox_Beschreibung.Name = "textBox_Beschreibung";
            this.textBox_Beschreibung.Size = new System.Drawing.Size(530, 48);
            this.textBox_Beschreibung.TabIndex = 5;
            // 
            // btn_Speichern
            // 
            this.btn_Speichern.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btn_Speichern.Location = new System.Drawing.Point(153, 378);
            this.btn_Speichern.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btn_Speichern.Name = "btn_Speichern";
            this.btn_Speichern.Size = new System.Drawing.Size(91, 34);
            this.btn_Speichern.TabIndex = 6;
            this.btn_Speichern.Text = "Speichern";
            this.btn_Speichern.UseVisualStyleBackColor = true;
            this.btn_Speichern.Click += new System.EventHandler(this.btn_Speichern_Click);
            // 
            // btn_Speichern_Unter
            // 
            this.btn_Speichern_Unter.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btn_Speichern_Unter.Location = new System.Drawing.Point(258, 378);
            this.btn_Speichern_Unter.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btn_Speichern_Unter.Name = "btn_Speichern_Unter";
            this.btn_Speichern_Unter.Size = new System.Drawing.Size(106, 34);
            this.btn_Speichern_Unter.TabIndex = 7;
            this.btn_Speichern_Unter.Text = "Speichern unter";
            this.btn_Speichern_Unter.UseVisualStyleBackColor = true;
            this.btn_Speichern_Unter.Click += new System.EventHandler(this.btn_Speichern_Unter_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btn_OK.Location = new System.Drawing.Point(554, 378);
            this.btn_OK.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(91, 34);
            this.btn_OK.TabIndex = 8;
            this.btn_OK.Text = "Beenden";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_Ueberschreiben
            // 
            this.btn_Ueberschreiben.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btn_Ueberschreiben.Location = new System.Drawing.Point(378, 378);
            this.btn_Ueberschreiben.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.btn_Ueberschreiben.Name = "btn_Ueberschreiben";
            this.btn_Ueberschreiben.Size = new System.Drawing.Size(102, 34);
            this.btn_Ueberschreiben.TabIndex = 9;
            this.btn_Ueberschreiben.Text = "�berschreiben";
            this.btn_Ueberschreiben.UseVisualStyleBackColor = true;
            this.btn_Ueberschreiben.Click += new System.EventHandler(this.btn_Ueberschreiben_Click);
            // 
            // textBox_Stromname
            // 
            this.textBox_Stromname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_Stromname.Enabled = false;
            this.textBox_Stromname.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox_Stromname.Location = new System.Drawing.Point(115, 32);
            this.textBox_Stromname.Margin = new System.Windows.Forms.Padding(5);
            this.textBox_Stromname.Name = "textBox_Stromname";
            this.textBox_Stromname.Size = new System.Drawing.Size(212, 25);
            this.textBox_Stromname.TabIndex = 10;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label4.Location = new System.Drawing.Point(101, 159);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(52, 19);
            this.Label4.TabIndex = 12;
            this.Label4.Text = "Januar:";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert1
            // 
            this.Wert1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert1.Location = new System.Drawing.Point(161, 159);
            this.Wert1.Margin = new System.Windows.Forms.Padding(5);
            this.Wert1.Name = "Wert1";
            this.Wert1.Size = new System.Drawing.Size(82, 25);
            this.Wert1.TabIndex = 13;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.Color.Black;
            this.Label5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label5.ForeColor = System.Drawing.Color.White;
            this.Label5.Location = new System.Drawing.Point(251, 159);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(43, 19);
            this.Label5.TabIndex = 14;
            this.Label5.Text = "MWh";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label6.Location = new System.Drawing.Point(94, 192);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(59, 19);
            this.Label6.TabIndex = 15;
            this.Label6.Text = "Februar:";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert2
            // 
            this.Wert2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert2.Location = new System.Drawing.Point(161, 191);
            this.Wert2.Margin = new System.Windows.Forms.Padding(5);
            this.Wert2.Name = "Wert2";
            this.Wert2.Size = new System.Drawing.Size(82, 25);
            this.Wert2.TabIndex = 16;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.BackColor = System.Drawing.Color.Black;
            this.Label7.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(251, 192);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(43, 19);
            this.Label7.TabIndex = 17;
            this.Label7.Text = "MWh";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label8.Location = new System.Drawing.Point(110, 223);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(43, 19);
            this.Label8.TabIndex = 18;
            this.Label8.Text = "M�rz:";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert3
            // 
            this.Wert3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert3.Location = new System.Drawing.Point(161, 222);
            this.Wert3.Margin = new System.Windows.Forms.Padding(5);
            this.Wert3.Name = "Wert3";
            this.Wert3.Size = new System.Drawing.Size(82, 25);
            this.Wert3.TabIndex = 19;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.BackColor = System.Drawing.Color.Black;
            this.Label9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(251, 223);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(43, 19);
            this.Label9.TabIndex = 20;
            this.Label9.Text = "MWh";
            this.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label10.Location = new System.Drawing.Point(113, 254);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(40, 19);
            this.Label10.TabIndex = 21;
            this.Label10.Text = "April:";
            this.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert4
            // 
            this.Wert4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert4.Location = new System.Drawing.Point(161, 253);
            this.Wert4.Margin = new System.Windows.Forms.Padding(5);
            this.Wert4.Name = "Wert4";
            this.Wert4.Size = new System.Drawing.Size(82, 25);
            this.Wert4.TabIndex = 22;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.BackColor = System.Drawing.Color.Black;
            this.Label11.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label11.ForeColor = System.Drawing.Color.White;
            this.Label11.Location = new System.Drawing.Point(251, 254);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(43, 19);
            this.Label11.TabIndex = 23;
            this.Label11.Text = "MWh";
            this.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label12.Location = new System.Drawing.Point(118, 286);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(35, 19);
            this.Label12.TabIndex = 24;
            this.Label12.Text = "Mai:";
            this.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert5
            // 
            this.Wert5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert5.Location = new System.Drawing.Point(161, 285);
            this.Wert5.Margin = new System.Windows.Forms.Padding(5);
            this.Wert5.Name = "Wert5";
            this.Wert5.Size = new System.Drawing.Size(82, 25);
            this.Wert5.TabIndex = 25;
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.BackColor = System.Drawing.Color.Black;
            this.Label13.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label13.ForeColor = System.Drawing.Color.White;
            this.Label13.Location = new System.Drawing.Point(251, 286);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(43, 19);
            this.Label13.TabIndex = 26;
            this.Label13.Text = "MWh";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label14.Location = new System.Drawing.Point(117, 317);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(36, 19);
            this.Label14.TabIndex = 27;
            this.Label14.Text = "Juni:";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.BackColor = System.Drawing.Color.Black;
            this.Label15.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label15.ForeColor = System.Drawing.Color.White;
            this.Label15.Location = new System.Drawing.Point(251, 317);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(43, 19);
            this.Label15.TabIndex = 28;
            this.Label15.Text = "MWh";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Wert8
            // 
            this.Wert8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert8.Location = new System.Drawing.Point(413, 191);
            this.Wert8.Margin = new System.Windows.Forms.Padding(5);
            this.Wert8.Name = "Wert8";
            this.Wert8.Size = new System.Drawing.Size(82, 25);
            this.Wert8.TabIndex = 29;
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.BackColor = System.Drawing.Color.Black;
            this.Label16.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label16.ForeColor = System.Drawing.Color.White;
            this.Label16.Location = new System.Drawing.Point(503, 159);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(43, 19);
            this.Label16.TabIndex = 30;
            this.Label16.Text = "MWh";
            this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label17.Location = new System.Drawing.Point(374, 161);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(31, 19);
            this.Label17.TabIndex = 31;
            this.Label17.Text = "Juli:";
            this.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert7
            // 
            this.Wert7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert7.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert7.Location = new System.Drawing.Point(413, 159);
            this.Wert7.Margin = new System.Windows.Forms.Padding(5);
            this.Wert7.Name = "Wert7";
            this.Wert7.Size = new System.Drawing.Size(82, 25);
            this.Wert7.TabIndex = 32;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label18.Location = new System.Drawing.Point(349, 194);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(56, 19);
            this.Label18.TabIndex = 33;
            this.Label18.Text = "August:";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.BackColor = System.Drawing.Color.Black;
            this.Label19.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label19.ForeColor = System.Drawing.Color.White;
            this.Label19.Location = new System.Drawing.Point(503, 192);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(43, 19);
            this.Label19.TabIndex = 34;
            this.Label19.Text = "MWh";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label20.Location = new System.Drawing.Point(327, 225);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(78, 19);
            this.Label20.TabIndex = 35;
            this.Label20.Text = "September:";
            this.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert9
            // 
            this.Wert9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert9.Location = new System.Drawing.Point(413, 222);
            this.Wert9.Margin = new System.Windows.Forms.Padding(5);
            this.Wert9.Name = "Wert9";
            this.Wert9.Size = new System.Drawing.Size(82, 25);
            this.Wert9.TabIndex = 36;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.BackColor = System.Drawing.Color.Black;
            this.Label21.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label21.ForeColor = System.Drawing.Color.White;
            this.Label21.Location = new System.Drawing.Point(503, 223);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(43, 19);
            this.Label21.TabIndex = 37;
            this.Label21.Text = "MWh";
            this.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label22
            // 
            this.Label22.AutoSize = true;
            this.Label22.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label22.Location = new System.Drawing.Point(342, 256);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(63, 19);
            this.Label22.TabIndex = 38;
            this.Label22.Text = "Oktober:";
            this.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert10
            // 
            this.Wert10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert10.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert10.Location = new System.Drawing.Point(413, 253);
            this.Wert10.Margin = new System.Windows.Forms.Padding(5);
            this.Wert10.Name = "Wert10";
            this.Wert10.Size = new System.Drawing.Size(82, 25);
            this.Wert10.TabIndex = 39;
            // 
            // Label23
            // 
            this.Label23.AutoSize = true;
            this.Label23.BackColor = System.Drawing.Color.Black;
            this.Label23.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label23.ForeColor = System.Drawing.Color.White;
            this.Label23.Location = new System.Drawing.Point(503, 254);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(43, 19);
            this.Label23.TabIndex = 40;
            this.Label23.Text = "MWh";
            this.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label24.Location = new System.Drawing.Point(317, 288);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(88, 19);
            this.Label24.TabIndex = 41;
            this.Label24.Text = "Novmember:";
            this.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Wert11
            // 
            this.Wert11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert11.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert11.Location = new System.Drawing.Point(413, 285);
            this.Wert11.Margin = new System.Windows.Forms.Padding(5);
            this.Wert11.Name = "Wert11";
            this.Wert11.Size = new System.Drawing.Size(82, 25);
            this.Wert11.TabIndex = 42;
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.BackColor = System.Drawing.Color.Black;
            this.Label25.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label25.ForeColor = System.Drawing.Color.White;
            this.Label25.Location = new System.Drawing.Point(503, 286);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(43, 19);
            this.Label25.TabIndex = 43;
            this.Label25.Text = "MWh";
            this.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Wert12
            // 
            this.Wert12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert12.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert12.Location = new System.Drawing.Point(413, 316);
            this.Wert12.Margin = new System.Windows.Forms.Padding(5);
            this.Wert12.Name = "Wert12";
            this.Wert12.Size = new System.Drawing.Size(82, 25);
            this.Wert12.TabIndex = 44;
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label26.Location = new System.Drawing.Point(334, 319);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(71, 19);
            this.Label26.TabIndex = 45;
            this.Label26.Text = "Dezember";
            this.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.BackColor = System.Drawing.Color.Black;
            this.Label27.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Label27.ForeColor = System.Drawing.Color.White;
            this.Label27.Location = new System.Drawing.Point(503, 317);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(43, 19);
            this.Label27.TabIndex = 46;
            this.Label27.Text = "MWh";
            this.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Wert6
            // 
            this.Wert6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Wert6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Wert6.Location = new System.Drawing.Point(161, 316);
            this.Wert6.Margin = new System.Windows.Forms.Padding(5);
            this.Wert6.Name = "Wert6";
            this.Wert6.Size = new System.Drawing.Size(82, 25);
            this.Wert6.TabIndex = 47;
            // 
            // Form_EingDBStromverbraucher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 426);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.comboBox_Stromtyp);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.textBox_Beschreibung);
            this.Controls.Add(this.btn_Speichern);
            this.Controls.Add(this.btn_Speichern_Unter);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btn_Ueberschreiben);
            this.Controls.Add(this.textBox_Stromname);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Wert1);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Wert2);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Wert3);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Wert4);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Wert5);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label14);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.Wert8);
            this.Controls.Add(this.Label16);
            this.Controls.Add(this.Label17);
            this.Controls.Add(this.Wert7);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.Label20);
            this.Controls.Add(this.Wert9);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.Label22);
            this.Controls.Add(this.Wert10);
            this.Controls.Add(this.Label23);
            this.Controls.Add(this.Label24);
            this.Controls.Add(this.Wert11);
            this.Controls.Add(this.Label25);
            this.Controls.Add(this.Wert12);
            this.Controls.Add(this.Label26);
            this.Controls.Add(this.Label27);
            this.Controls.Add(this.Wert6);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "Form_EingDBStromverbraucher";
            this.Text = "Eingabe Stromverbraucher";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label1;
private System.Windows.Forms.Label Label2;
private System.Windows.Forms.ComboBox comboBox_Stromtyp;
private System.Windows.Forms.Label Label3;
private System.Windows.Forms.TextBox textBox_Beschreibung;
private System.Windows.Forms.Button btn_Speichern;
private System.Windows.Forms.Button btn_Speichern_Unter;
private System.Windows.Forms.Button btn_OK;
private System.Windows.Forms.Button btn_Ueberschreiben;
private System.Windows.Forms.TextBox textBox_Stromname;
private System.Windows.Forms.Label Label4;
private System.Windows.Forms.TextBox Wert1;
private System.Windows.Forms.Label Label5;
private System.Windows.Forms.Label Label6;
private System.Windows.Forms.TextBox Wert2;
private System.Windows.Forms.Label Label7;
private System.Windows.Forms.Label Label8;
private System.Windows.Forms.TextBox Wert3;
private System.Windows.Forms.Label Label9;
private System.Windows.Forms.Label Label10;
private System.Windows.Forms.TextBox Wert4;
private System.Windows.Forms.Label Label11;
private System.Windows.Forms.Label Label12;
private System.Windows.Forms.TextBox Wert5;
private System.Windows.Forms.Label Label13;
private System.Windows.Forms.Label Label14;
private System.Windows.Forms.Label Label15;
private System.Windows.Forms.TextBox Wert8;
private System.Windows.Forms.Label Label16;
private System.Windows.Forms.Label Label17;
private System.Windows.Forms.TextBox Wert7;
private System.Windows.Forms.Label Label18;
private System.Windows.Forms.Label Label19;
private System.Windows.Forms.Label Label20;
private System.Windows.Forms.TextBox Wert9;
private System.Windows.Forms.Label Label21;
private System.Windows.Forms.Label Label22;
private System.Windows.Forms.TextBox Wert10;
private System.Windows.Forms.Label Label23;
private System.Windows.Forms.Label Label24;
private System.Windows.Forms.TextBox Wert11;
private System.Windows.Forms.Label Label25;
private System.Windows.Forms.TextBox Wert12;
private System.Windows.Forms.Label Label26;
private System.Windows.Forms.Label Label27;
private System.Windows.Forms.TextBox Wert6;


 
    }
}