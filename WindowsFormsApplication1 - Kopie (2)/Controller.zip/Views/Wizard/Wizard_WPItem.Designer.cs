﻿namespace WindowsFormsApplication1
{
    partial class Wizard_WPItem
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Wizard_WPItem));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.btn_Beenden = new System.Windows.Forms.Button();
            this.btn_Abbrechen = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox_PHeizstab = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox_Ruecklauf = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_Vorlauf = new System.Windows.Forms.ComboBox();
            this.textBox_Abschalttemp = new System.Windows.Forms.TextBox();
            this.label_AbschalttemperaturEinheit = new System.Windows.Forms.Label();
            this.label_Abschalttemperatur = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox_Betriebsart = new System.Windows.Forms.ComboBox();
            this.checkBox_Bivalent = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_bis = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_von = new System.Windows.Forms.TextBox();
            this.checkBox_Sperrzeit = new System.Windows.Forms.CheckBox();
            this.checkBox_Heizstab = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox_rendeMIX = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_Anteil = new System.Windows.Forms.TextBox();
            this.textBox_Kapazität = new System.Windows.Forms.TextBox();
            this.textBox_Volumen = new System.Windows.Forms.TextBox();
            this.label_WP = new System.Windows.Forms.Label();
            this.listBox_WP = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox_Nutzungszeit = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_Baujahr = new System.Windows.Forms.TextBox();
            this.textBox_Leistungsstufen = new System.Windows.Forms.TextBox();
            this.textBox_Waermepumpentyp = new System.Windows.Forms.TextBox();
            this.btn_WP = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox_Modulkosten = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox_Beschreibung = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox_Hersteller = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox_Nennleistung = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Beenden
            // 
            this.btn_Beenden.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btn_Beenden.Location = new System.Drawing.Point(856, 616);
            this.btn_Beenden.Name = "btn_Beenden";
            this.btn_Beenden.Size = new System.Drawing.Size(95, 27);
            this.btn_Beenden.TabIndex = 48;
            this.btn_Beenden.Text = "OK";
            this.btn_Beenden.UseVisualStyleBackColor = true;
            this.btn_Beenden.Click += new System.EventHandler(this.btn_Beenden_Click);
            // 
            // btn_Abbrechen
            // 
            this.btn_Abbrechen.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btn_Abbrechen.Location = new System.Drawing.Point(744, 616);
            this.btn_Abbrechen.Name = "btn_Abbrechen";
            this.btn_Abbrechen.Size = new System.Drawing.Size(95, 27);
            this.btn_Abbrechen.TabIndex = 49;
            this.btn_Abbrechen.Text = "Abbrechen";
            this.btn_Abbrechen.UseVisualStyleBackColor = true;
            this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Aqua;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.label23.Location = new System.Drawing.Point(46, 444);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(429, 73);
            this.label23.TabIndex = 82;
            this.label23.Text = resources.GetString("label23.Text");
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label22.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.label22.Location = new System.Drawing.Point(46, 387);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(429, 57);
            this.label22.TabIndex = 81;
            this.label22.Text = resources.GetString("label22.Text");
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label21.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.label21.Location = new System.Drawing.Point(46, 330);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(429, 57);
            this.label21.TabIndex = 80;
            this.label21.Text = resources.GetString("label21.Text");
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(46, 240);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(228, 17);
            this.label20.TabIndex = 79;
            this.label20.Text = "Außentemperaturgesteuerter  Betrieb:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(46, 179);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(285, 17);
            this.label19.TabIndex = 78;
            this.label19.Text = "Wärmepumpenleistung / maximale Betriebszeit:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Navy;
            this.label18.Location = new System.Drawing.Point(19, 150);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(397, 17);
            this.label18.TabIndex = 77;
            this.label18.Text = "Ein Spitzenlast Wärmeerzeuger kann notwendig sein aufgrund:";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Black;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(196, 194);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(33, 19);
            this.label17.TabIndex = 58;
            this.label17.Text = "kW";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_PHeizstab
            // 
            this.textBox_PHeizstab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.textBox_PHeizstab.Location = new System.Drawing.Point(124, 193);
            this.textBox_PHeizstab.Name = "textBox_PHeizstab";
            this.textBox_PHeizstab.Size = new System.Drawing.Size(66, 20);
            this.textBox_PHeizstab.TabIndex = 76;
            this.textBox_PHeizstab.Text = "17";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Navy;
            this.label7.Location = new System.Drawing.Point(19, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(180, 17);
            this.label7.TabIndex = 75;
            this.label7.Text = "Wärmeerzeuger Spitzenlast:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.comboBox_Ruecklauf);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.comboBox_Vorlauf);
            this.groupBox3.Location = new System.Drawing.Point(460, 28);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(181, 96);
            this.groupBox3.TabIndex = 74;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Auslegung für Verteilung";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(140, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 19);
            this.label11.TabIndex = 41;
            this.label11.Text = "°C";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Black;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(140, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 19);
            this.label10.TabIndex = 38;
            this.label10.Text = "°C";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "Rücklauf";
            // 
            // comboBox_Ruecklauf
            // 
            this.comboBox_Ruecklauf.FormattingEnabled = true;
            this.comboBox_Ruecklauf.Location = new System.Drawing.Point(79, 61);
            this.comboBox_Ruecklauf.Name = "comboBox_Ruecklauf";
            this.comboBox_Ruecklauf.Size = new System.Drawing.Size(55, 21);
            this.comboBox_Ruecklauf.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 37;
            this.label8.Text = "Vorlauf";
            // 
            // comboBox_Vorlauf
            // 
            this.comboBox_Vorlauf.FormattingEnabled = true;
            this.comboBox_Vorlauf.Location = new System.Drawing.Point(81, 26);
            this.comboBox_Vorlauf.Name = "comboBox_Vorlauf";
            this.comboBox_Vorlauf.Size = new System.Drawing.Size(55, 21);
            this.comboBox_Vorlauf.TabIndex = 36;
            // 
            // textBox_Abschalttemp
            // 
            this.textBox_Abschalttemp.Location = new System.Drawing.Point(375, 296);
            this.textBox_Abschalttemp.Name = "textBox_Abschalttemp";
            this.textBox_Abschalttemp.Size = new System.Drawing.Size(50, 20);
            this.textBox_Abschalttemp.TabIndex = 72;
            this.textBox_Abschalttemp.Text = "0";
            // 
            // label_AbschalttemperaturEinheit
            // 
            this.label_AbschalttemperaturEinheit.BackColor = System.Drawing.Color.Black;
            this.label_AbschalttemperaturEinheit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AbschalttemperaturEinheit.ForeColor = System.Drawing.Color.White;
            this.label_AbschalttemperaturEinheit.Location = new System.Drawing.Point(431, 296);
            this.label_AbschalttemperaturEinheit.Name = "label_AbschalttemperaturEinheit";
            this.label_AbschalttemperaturEinheit.Size = new System.Drawing.Size(23, 19);
            this.label_AbschalttemperaturEinheit.TabIndex = 71;
            this.label_AbschalttemperaturEinheit.Text = "°C";
            this.label_AbschalttemperaturEinheit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Abschalttemperatur
            // 
            this.label_Abschalttemperatur.Location = new System.Drawing.Point(270, 299);
            this.label_Abschalttemperatur.Name = "label_Abschalttemperatur";
            this.label_Abschalttemperatur.Size = new System.Drawing.Size(99, 17);
            this.label_Abschalttemperatur.TabIndex = 70;
            this.label_Abschalttemperatur.Text = "Abschalttemperatur";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(38, 296);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 13);
            this.label14.TabIndex = 69;
            this.label14.Text = "Betriebsart";
            // 
            // comboBox_Betriebsart
            // 
            this.comboBox_Betriebsart.FormattingEnabled = true;
            this.comboBox_Betriebsart.Location = new System.Drawing.Point(101, 294);
            this.comboBox_Betriebsart.Name = "comboBox_Betriebsart";
            this.comboBox_Betriebsart.Size = new System.Drawing.Size(131, 21);
            this.comboBox_Betriebsart.TabIndex = 68;
            this.comboBox_Betriebsart.SelectedIndexChanged += new System.EventHandler(this.comboBox_Betriebsart_SelectedIndexChanged);
            // 
            // checkBox_Bivalent
            // 
            this.checkBox_Bivalent.Location = new System.Drawing.Point(49, 263);
            this.checkBox_Bivalent.Name = "checkBox_Bivalent";
            this.checkBox_Bivalent.Size = new System.Drawing.Size(146, 31);
            this.checkBox_Bivalent.TabIndex = 67;
            this.checkBox_Bivalent.Text = "Bivalenter Betrieb";
            this.checkBox_Bivalent.UseVisualStyleBackColor = true;
            this.checkBox_Bivalent.CheckedChanged += new System.EventHandler(this.checkBox_Bivalent_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(363, 203);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 13);
            this.label13.TabIndex = 66;
            this.label13.Text = "bis";
            // 
            // textBox_bis
            // 
            this.textBox_bis.Location = new System.Drawing.Point(389, 200);
            this.textBox_bis.Name = "textBox_bis";
            this.textBox_bis.Size = new System.Drawing.Size(27, 20);
            this.textBox_bis.TabIndex = 65;
            this.textBox_bis.Text = "17";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(290, 202);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 13);
            this.label12.TabIndex = 64;
            this.label12.Text = "von";
            // 
            // textBox_von
            // 
            this.textBox_von.Location = new System.Drawing.Point(328, 199);
            this.textBox_von.Name = "textBox_von";
            this.textBox_von.Size = new System.Drawing.Size(29, 20);
            this.textBox_von.TabIndex = 63;
            this.textBox_von.Text = "14";
            // 
            // checkBox_Sperrzeit
            // 
            this.checkBox_Sperrzeit.Location = new System.Drawing.Point(49, 199);
            this.checkBox_Sperrzeit.Name = "checkBox_Sperrzeit";
            this.checkBox_Sperrzeit.Size = new System.Drawing.Size(247, 25);
            this.checkBox_Sperrzeit.TabIndex = 62;
            this.checkBox_Sperrzeit.Text = "Sperrzeit durch Energieversorger";
            this.checkBox_Sperrzeit.UseVisualStyleBackColor = true;
            // 
            // checkBox_Heizstab
            // 
            this.checkBox_Heizstab.Location = new System.Drawing.Point(22, 91);
            this.checkBox_Heizstab.Name = "checkBox_Heizstab";
            this.checkBox_Heizstab.Size = new System.Drawing.Size(274, 31);
            this.checkBox_Heizstab.TabIndex = 61;
            this.checkBox_Heizstab.Text = "Elektrische Nachheizung aktivieren (falls vorhanden)";
            this.checkBox_Heizstab.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox_rendeMIX);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_Anteil);
            this.groupBox1.Controls.Add(this.textBox_Kapazität);
            this.groupBox1.Controls.Add(this.textBox_Volumen);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.groupBox1.Location = new System.Drawing.Point(22, 558);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(677, 85);
            this.groupBox1.TabIndex = 60;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pufferspeicher";
            // 
            // checkBox_rendeMIX
            // 
            this.checkBox_rendeMIX.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_rendeMIX.Location = new System.Drawing.Point(17, 58);
            this.checkBox_rendeMIX.Name = "checkBox_rendeMIX";
            this.checkBox_rendeMIX.Size = new System.Drawing.Size(385, 29);
            this.checkBox_rendeMIX.TabIndex = 10;
            this.checkBox_rendeMIX.Text = "Pufferspeicher mit optimiertem Ladesystem (rende MIX)";
            this.checkBox_rendeMIX.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(638, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "%";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(368, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "kWth";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(147, 30);
            this.label4.Margin = new System.Windows.Forms.Padding(3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "ᵐ³";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(438, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 44);
            this.label3.TabIndex = 5;
            this.label3.Text = "Anteil Speicher für Solaranlage";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(238, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Kapazität";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Volumen";
            // 
            // textBox_Anteil
            // 
            this.textBox_Anteil.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Anteil.Location = new System.Drawing.Point(572, 30);
            this.textBox_Anteil.Name = "textBox_Anteil";
            this.textBox_Anteil.Size = new System.Drawing.Size(59, 22);
            this.textBox_Anteil.TabIndex = 2;
            this.textBox_Anteil.Text = "0";
            // 
            // textBox_Kapazität
            // 
            this.textBox_Kapazität.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Kapazität.Location = new System.Drawing.Point(302, 30);
            this.textBox_Kapazität.Name = "textBox_Kapazität";
            this.textBox_Kapazität.Size = new System.Drawing.Size(59, 22);
            this.textBox_Kapazität.TabIndex = 1;
            // 
            // textBox_Volumen
            // 
            this.textBox_Volumen.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Volumen.Location = new System.Drawing.Point(82, 30);
            this.textBox_Volumen.Name = "textBox_Volumen";
            this.textBox_Volumen.Size = new System.Drawing.Size(59, 22);
            this.textBox_Volumen.TabIndex = 0;
            this.textBox_Volumen.Text = "10";
            // 
            // label_WP
            // 
            this.label_WP.AutoSize = true;
            this.label_WP.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label_WP.Location = new System.Drawing.Point(14, 11);
            this.label_WP.Name = "label_WP";
            this.label_WP.Size = new System.Drawing.Size(162, 19);
            this.label_WP.TabIndex = 59;
            this.label_WP.Text = "Wärmepumpen Auswahl:";
            // 
            // listBox_WP
            // 
            this.listBox_WP.FormattingEnabled = true;
            this.listBox_WP.Location = new System.Drawing.Point(18, 35);
            this.listBox_WP.Name = "listBox_WP";
            this.listBox_WP.Size = new System.Drawing.Size(339, 21);
            this.listBox_WP.TabIndex = 97;
            this.listBox_WP.SelectedIndexChanged += new System.EventHandler(this.listBox_WP_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label24.Location = new System.Drawing.Point(594, 308);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(145, 19);
            this.label24.TabIndex = 126;
            this.label24.Text = "Kenndaten Kennlinien:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(465, 135);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(79, 13);
            this.label31.TabIndex = 128;
            this.label31.Text = "Nutzungsdauer";
            // 
            // textBox_Nutzungszeit
            // 
            this.textBox_Nutzungszeit.Location = new System.Drawing.Point(541, 135);
            this.textBox_Nutzungszeit.Name = "textBox_Nutzungszeit";
            this.textBox_Nutzungszeit.Size = new System.Drawing.Size(53, 20);
            this.textBox_Nutzungszeit.TabIndex = 127;
            this.textBox_Nutzungszeit.Text = "20";
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.Black;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(600, 134);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(23, 19);
            this.label34.TabIndex = 42;
            this.label34.Text = "a";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.Black;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(422, 199);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(42, 19);
            this.label35.TabIndex = 129;
            this.label35.Text = "h/Tag";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.textBox_Baujahr);
            this.groupBox2.Controls.Add(this.textBox_Leistungsstufen);
            this.groupBox2.Controls.Add(this.textBox_Waermepumpentyp);
            this.groupBox2.Controls.Add(this.btn_WP);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.textBox_Modulkosten);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.textBox_Beschreibung);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.textBox_Hersteller);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.textBox_PHeizstab);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.textBox_Nennleistung);
            this.groupBox2.Location = new System.Drawing.Point(653, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(298, 277);
            this.groupBox2.TabIndex = 133;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Wärmepumpen Kenndaten";
            // 
            // textBox_Baujahr
            // 
            this.textBox_Baujahr.BackColor = System.Drawing.Color.White;
            this.textBox_Baujahr.Location = new System.Drawing.Point(126, 126);
            this.textBox_Baujahr.Name = "textBox_Baujahr";
            this.textBox_Baujahr.ReadOnly = true;
            this.textBox_Baujahr.Size = new System.Drawing.Size(60, 20);
            this.textBox_Baujahr.TabIndex = 153;
            this.textBox_Baujahr.Text = "2025";
            // 
            // textBox_Leistungsstufen
            // 
            this.textBox_Leistungsstufen.BackColor = System.Drawing.Color.White;
            this.textBox_Leistungsstufen.Location = new System.Drawing.Point(124, 74);
            this.textBox_Leistungsstufen.Name = "textBox_Leistungsstufen";
            this.textBox_Leistungsstufen.ReadOnly = true;
            this.textBox_Leistungsstufen.Size = new System.Drawing.Size(155, 20);
            this.textBox_Leistungsstufen.TabIndex = 152;
            // 
            // textBox_Waermepumpentyp
            // 
            this.textBox_Waermepumpentyp.BackColor = System.Drawing.Color.White;
            this.textBox_Waermepumpentyp.Location = new System.Drawing.Point(124, 48);
            this.textBox_Waermepumpentyp.Name = "textBox_Waermepumpentyp";
            this.textBox_Waermepumpentyp.ReadOnly = true;
            this.textBox_Waermepumpentyp.Size = new System.Drawing.Size(156, 20);
            this.textBox_Waermepumpentyp.TabIndex = 151;
            // 
            // btn_WP
            // 
            this.btn_WP.Location = new System.Drawing.Point(28, 247);
            this.btn_WP.Name = "btn_WP";
            this.btn_WP.Size = new System.Drawing.Size(164, 22);
            this.btn_WP.TabIndex = 149;
            this.btn_WP.Text = "Bearbeiten...";
            this.btn_WP.UseVisualStyleBackColor = true;
            this.btn_WP.Click += new System.EventHandler(this.btn_WP_Click);
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.Black;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(190, 19);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(33, 19);
            this.label36.TabIndex = 148;
            this.label36.Text = "kW";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.Black;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(196, 221);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(23, 19);
            this.label33.TabIndex = 133;
            this.label33.Text = "€";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(25, 221);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(68, 13);
            this.label32.TabIndex = 147;
            this.label32.Text = "Modulkosten";
            // 
            // textBox_Modulkosten
            // 
            this.textBox_Modulkosten.BackColor = System.Drawing.Color.White;
            this.textBox_Modulkosten.Location = new System.Drawing.Point(124, 221);
            this.textBox_Modulkosten.Name = "textBox_Modulkosten";
            this.textBox_Modulkosten.ReadOnly = true;
            this.textBox_Modulkosten.Size = new System.Drawing.Size(66, 20);
            this.textBox_Modulkosten.TabIndex = 146;
            this.textBox_Modulkosten.Text = "12000";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(25, 125);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(43, 13);
            this.label29.TabIndex = 145;
            this.label29.Text = "Baujahr";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(25, 152);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 13);
            this.label28.TabIndex = 143;
            this.label28.Text = "Bezeichnung";
            // 
            // textBox_Beschreibung
            // 
            this.textBox_Beschreibung.BackColor = System.Drawing.Color.White;
            this.textBox_Beschreibung.Location = new System.Drawing.Point(124, 152);
            this.textBox_Beschreibung.Multiline = true;
            this.textBox_Beschreibung.Name = "textBox_Beschreibung";
            this.textBox_Beschreibung.ReadOnly = true;
            this.textBox_Beschreibung.Size = new System.Drawing.Size(157, 35);
            this.textBox_Beschreibung.TabIndex = 142;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(25, 99);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 13);
            this.label27.TabIndex = 141;
            this.label27.Text = "Hersteller";
            // 
            // textBox_Hersteller
            // 
            this.textBox_Hersteller.BackColor = System.Drawing.Color.White;
            this.textBox_Hersteller.Location = new System.Drawing.Point(124, 99);
            this.textBox_Hersteller.Name = "textBox_Hersteller";
            this.textBox_Hersteller.ReadOnly = true;
            this.textBox_Hersteller.Size = new System.Drawing.Size(157, 20);
            this.textBox_Hersteller.TabIndex = 140;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(25, 76);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(81, 13);
            this.label26.TabIndex = 139;
            this.label26.Text = "Leistungsstufen";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(25, 49);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 13);
            this.label25.TabIndex = 137;
            this.label25.Text = "Wärmepumpentyp";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(25, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(69, 13);
            this.label30.TabIndex = 135;
            this.label30.Text = "Nennleistung";
            // 
            // textBox_Nennleistung
            // 
            this.textBox_Nennleistung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.textBox_Nennleistung.Location = new System.Drawing.Point(124, 19);
            this.textBox_Nennleistung.Name = "textBox_Nennleistung";
            this.textBox_Nennleistung.ReadOnly = true;
            this.textBox_Nennleistung.Size = new System.Drawing.Size(60, 20);
            this.textBox_Nennleistung.TabIndex = 134;
            this.textBox_Nennleistung.Text = "15";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(594, 330);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(368, 225);
            this.tabControl1.TabIndex = 154;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(360, 199);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "COP";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea5.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea5.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.chart1.Legends.Add(legend5);
            this.chart1.Location = new System.Drawing.Point(6, 6);
            this.chart1.Name = "chart1";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.MarkerBorderWidth = 3;
            series5.Name = "Series1";
            this.chart1.Series.Add(series5);
            this.chart1.Size = new System.Drawing.Size(337, 189);
            this.chart1.TabIndex = 125;
            this.chart1.Text = "COP";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chart2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(360, 199);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Leistung";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chart2
            // 
            chartArea6.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea6.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.chart2.Legends.Add(legend6);
            this.chart2.Location = new System.Drawing.Point(12, 6);
            this.chart2.Name = "chart2";
            series6.ChartArea = "ChartArea1";
            series6.Legend = "Legend1";
            series6.MarkerBorderWidth = 3;
            series6.Name = "Series1";
            this.chart2.Series.Add(series6);
            this.chart2.Size = new System.Drawing.Size(337, 189);
            this.chart2.TabIndex = 126;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(25, 193);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 13);
            this.label15.TabIndex = 154;
            this.label15.Text = "Heizstab";
            // 
            // Wizard_WPItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 652);
            this.ControlBox = false;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.textBox_Nutzungszeit);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.listBox_WP);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.textBox_Abschalttemp);
            this.Controls.Add(this.label_AbschalttemperaturEinheit);
            this.Controls.Add(this.label_Abschalttemperatur);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.comboBox_Betriebsart);
            this.Controls.Add(this.checkBox_Bivalent);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBox_bis);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBox_von);
            this.Controls.Add(this.checkBox_Sperrzeit);
            this.Controls.Add(this.checkBox_Heizstab);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label_WP);
            this.Controls.Add(this.btn_Abbrechen);
            this.Controls.Add(this.btn_Beenden);
            this.Name = "Wizard_WPItem";
            this.Text = "Detailansicht";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Beenden;
        private System.Windows.Forms.Button btn_Abbrechen;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox_PHeizstab;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox_Ruecklauf;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_Vorlauf;
        private System.Windows.Forms.TextBox textBox_Abschalttemp;
        private System.Windows.Forms.Label label_AbschalttemperaturEinheit;
        private System.Windows.Forms.Label label_Abschalttemperatur;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox_Betriebsart;
        private System.Windows.Forms.CheckBox checkBox_Bivalent;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_bis;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_von;
        private System.Windows.Forms.CheckBox checkBox_Sperrzeit;
        private System.Windows.Forms.CheckBox checkBox_Heizstab;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox_rendeMIX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_Anteil;
        private System.Windows.Forms.TextBox textBox_Kapazität;
        private System.Windows.Forms.TextBox textBox_Volumen;
        private System.Windows.Forms.Label label_WP;
        private System.Windows.Forms.ComboBox listBox_WP;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox_Nutzungszeit;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_WP;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox_Modulkosten;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox_Beschreibung;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox_Hersteller;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox_Nennleistung;
        private System.Windows.Forms.TextBox textBox_Leistungsstufen;
        private System.Windows.Forms.TextBox textBox_Waermepumpentyp;
        private System.Windows.Forms.TextBox textBox_Baujahr;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Label label15;
    }
}