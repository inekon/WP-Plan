﻿namespace WindowsFormsApplication1
{
    partial class Wizard_Projekt
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_Beschreibung = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_Kunde = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_Bearbeiter = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_Aenderungsdatum = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_Gebaeude = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_Erstelldatum = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_Name
            // 
            this.textBox_Name.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox_Name.Location = new System.Drawing.Point(236, 205);
            this.textBox_Name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.Size = new System.Drawing.Size(355, 25);
            this.textBox_Name.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label1.Location = new System.Drawing.Point(82, 205);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Projektname";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label3.Location = new System.Drawing.Point(82, 253);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Beschreibung";
            // 
            // textBox_Beschreibung
            // 
            this.textBox_Beschreibung.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox_Beschreibung.Location = new System.Drawing.Point(236, 253);
            this.textBox_Beschreibung.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_Beschreibung.Multiline = true;
            this.textBox_Beschreibung.Name = "textBox_Beschreibung";
            this.textBox_Beschreibung.Size = new System.Drawing.Size(355, 126);
            this.textBox_Beschreibung.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label4.Location = new System.Drawing.Point(82, 399);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Kunde";
            // 
            // textBox_Kunde
            // 
            this.textBox_Kunde.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox_Kunde.Location = new System.Drawing.Point(236, 399);
            this.textBox_Kunde.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_Kunde.Name = "textBox_Kunde";
            this.textBox_Kunde.Size = new System.Drawing.Size(355, 25);
            this.textBox_Kunde.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label5.Location = new System.Drawing.Point(82, 447);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 19);
            this.label5.TabIndex = 10;
            this.label5.Text = "Bearbeiter";
            // 
            // textBox_Bearbeiter
            // 
            this.textBox_Bearbeiter.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBox_Bearbeiter.Location = new System.Drawing.Point(236, 447);
            this.textBox_Bearbeiter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_Bearbeiter.Name = "textBox_Bearbeiter";
            this.textBox_Bearbeiter.Size = new System.Drawing.Size(355, 25);
            this.textBox_Bearbeiter.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Logo125_125;
            this.pictureBox1.Location = new System.Drawing.Point(14, 49);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 100);
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DimGray;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(82, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(324, 19);
            this.label6.TabIndex = 15;
            this.label6.Text = "Geben Sie hier die administrativen Projektdaten ein:";
            // 
            // textBox_Aenderungsdatum
            // 
            this.textBox_Aenderungsdatum.Enabled = false;
            this.textBox_Aenderungsdatum.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Aenderungsdatum.Location = new System.Drawing.Point(236, 521);
            this.textBox_Aenderungsdatum.Name = "textBox_Aenderungsdatum";
            this.textBox_Aenderungsdatum.Size = new System.Drawing.Size(92, 25);
            this.textBox_Aenderungsdatum.TabIndex = 17;
            this.textBox_Aenderungsdatum.Text = "12.01.2020";
            this.textBox_Aenderungsdatum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(82, 521);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 19);
            this.label2.TabIndex = 18;
            this.label2.Text = "Änderungsdatum";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(0, 7, 0, 7);
            this.label7.Size = new System.Drawing.Size(631, 34);
            this.label7.TabIndex = 19;
            this.label7.Text = "Projektkonfiguration";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label8.Location = new System.Drawing.Point(82, 485);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 19);
            this.label8.TabIndex = 20;
            this.label8.Text = "Gebäude";
            // 
            // comboBox_Gebaeude
            // 
            this.comboBox_Gebaeude.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.comboBox_Gebaeude.FormattingEnabled = true;
            this.comboBox_Gebaeude.Location = new System.Drawing.Point(236, 482);
            this.comboBox_Gebaeude.Name = "comboBox_Gebaeude";
            this.comboBox_Gebaeude.Size = new System.Drawing.Size(355, 25);
            this.comboBox_Gebaeude.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label9.Location = new System.Drawing.Point(398, 521);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 19);
            this.label9.TabIndex = 23;
            this.label9.Text = "Erstelldatum";
            // 
            // textBox_Erstelldatum
            // 
            this.textBox_Erstelldatum.Enabled = false;
            this.textBox_Erstelldatum.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Erstelldatum.Location = new System.Drawing.Point(502, 521);
            this.textBox_Erstelldatum.Name = "textBox_Erstelldatum";
            this.textBox_Erstelldatum.Size = new System.Drawing.Size(92, 25);
            this.textBox_Erstelldatum.TabIndex = 22;
            this.textBox_Erstelldatum.Text = "12.01.2020";
            this.textBox_Erstelldatum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Wizard_Projekt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(631, 558);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox_Erstelldatum);
            this.Controls.Add(this.comboBox_Gebaeude);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_Aenderungsdatum);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_Bearbeiter);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_Kunde);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_Beschreibung);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_Name);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Wizard_Projekt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Projekte";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_Beschreibung;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_Kunde;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_Bearbeiter;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_Aenderungsdatum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_Gebaeude;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_Erstelldatum;
    }
}